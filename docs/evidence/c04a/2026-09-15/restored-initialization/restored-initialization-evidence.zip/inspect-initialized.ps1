. 'D:/CP6-audit-results/20260915/six-db-recovery/common.ps1'
$audit='D:/CP6-audit-results/20260915/restored-initialization'
$r=Get-Content -LiteralPath "$audit/initialization.json" -Raw|ConvertFrom-Json
$backups=Get-Content -LiteralPath 'D:/CP6-audit-results/20260915/six-db-recovery/recovery-report.json' -Raw|ConvertFrom-Json
if($r.execution.exitCode -ne 0){throw 'Initializer did not pass.'}
$auth=($r.restoredCopies|Where-Object role -eq 'auth-identity-catalog').database
$prior=($backups.items|Where-Object role -eq 'auth-identity-catalog').restoreDatabase
$source=Open-Sql 'native' $prior;$target=Open-Sql 'native' $auth
$preservation=@()
function Digest([string]$s){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($s))).ToLowerInvariant()}
try {
 $tables=Rows (Query $source "SELECT s.name schemaName,t.name tableName FROM sys.tables t JOIN sys.schemas s ON s.schema_id=t.schema_id ORDER BY s.name,t.name;")
 foreach($table in $tables) {
  $name=(Sql-Id $table.schemaName)+'.'+(Sql-Id $table.tableName)
  $keys=Rows (Query $source "SELECT c.name FROM sys.indexes i JOIN sys.index_columns ic ON ic.object_id=i.object_id AND ic.index_id=i.index_id JOIN sys.columns c ON c.object_id=ic.object_id AND c.column_id=ic.column_id WHERE i.is_primary_key=1 AND i.object_id=OBJECT_ID($(Sql-Text $name)) ORDER BY ic.key_ordinal;")
  if($keys.Count -eq 0){throw 'No deterministic primary key ordering.'}
  $order=($keys|ForEach-Object {Sql-Id $_.name}) -join ','
  $sql="SELECT (SELECT * FROM $name ORDER BY $order FOR JSON PATH,INCLUDE_NULL_VALUES) payload, (SELECT COUNT_BIG(*) FROM $name) n;"
  $a=Query $source $sql
  $targetSql=$sql
  if($table.tableName -in @('__IdentityMigrations','__EFMigrationsHistory')) {
   $targetSql="SELECT (SELECT * FROM $name WHERE MigrationId IN (SELECT MigrationId FROM $(Sql-Id $prior).$name) ORDER BY $order FOR JSON PATH,INCLUDE_NULL_VALUES) payload, (SELECT COUNT_BIG(*) FROM $name) n;"
  }
  $b=Query $target $targetSql
  $ha=Digest ([string]$a.Rows[0]['payload']);$hb=Digest ([string]$b.Rows[0]['payload'])
  if($ha -ne $hb){throw "Existing auth/identity/catalog content differs: $name"}
  $preservation += [ordered]@{schema=$table.schemaName;table=$table.tableName;rows=[long]$a.Rows[0]['n'];afterRows=[long]$b.Rows[0]['n'];aggregateSha256=$ha;preserved=$true;scope=if($table.tableName -in @('__IdentityMigrations','__EFMigrationsHistory')){'All preexisting migration rows retained; new forward migration rows allowed'}else{'All rows unchanged'}}
 }
 $readiness=Rows (Query $target 'SELECT OrganizationId,State,SchemaHash FROM crm_catalog.RuntimeReadiness ORDER BY OrganizationId;')
 if($readiness.Count -ne 2 -or @($readiness|Where-Object State -ne 'Ready').Count){throw 'Complete target readiness not Ready.'}
}finally{$source.Dispose();$target.Dispose()}
$targets=@()
foreach($item in @($r.restoredCopies|Where-Object role -like 'business-*')) {
 $c=Open-Sql 'native' $item.database
 try {
  $gate=Rows (Query $c 'SELECT State,Generation,OrganizationId FROM crm_cutover.Control;')
  if($gate.Count -ne 1 -or $gate[0].State -ne 'Closed' -or $gate[0].Generation -ne 0){throw 'Initial write gate is not Closed generation zero.'}
  $n=Rows (Query $c "SELECT (SELECT COUNT(*) FROM crm_v1.BusinessCalendar) calendars,(SELECT COUNT(*) FROM crm_v1.Site) sites,(SELECT COUNT(*) FROM crm_v1.PublicForm) forms,(SELECT COUNT(*) FROM sys.triggers WHERE name LIKE 'TR_RuntimeRetired_%' AND is_disabled=0) retiredTriggers,(SELECT COUNT(*) FROM crm_cutover.Audit) auditRows;")
  if($n[0].calendars -ne 0 -or $n[0].sites -ne 1 -or $n[0].forms -ne 1 -or $n[0].retiredTriggers -ne 4 -or $n[0].auditRows -ne 0){throw 'Unexpected initialization output.'}
  $targets += [ordered]@{role=$item.role;database=$item.database;gate=$gate[0];counts=$n[0]}
 }finally{$c.Dispose()}
}
Save-Json 'initialized-inspection.json' ([ordered]@{atUtc=[DateTimeOffset]::UtcNow.ToString('O');authIdentityPreservation=$preservation;readiness=$readiness;targets=$targets;initialCalendarStored=$false;applicationStartupTested=$false;actualActivation=$false;comparison='All rows/columns of retained auth tables in deterministic SQL JSON order; schema-local preservation proof, not CRM11 canonicalizer.'})
Write-Output "Both target copies Ready/Closed; 4 retired-source triggers each; $($preservation.Count) existing auth/identity/catalog tables preserved; initial calendar absent."
