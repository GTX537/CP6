param([switch]$ResumePreparedCopies)
. 'D:/CP6-audit-results/20260915/six-db-recovery/common.ps1'
$audit='D:/CP6-audit-results/20260915/restored-initialization'
$recovery=Get-Content -LiteralPath 'D:/CP6-audit-results/20260915/six-db-recovery/recovery-report.json' -Raw|ConvertFrom-Json
if($ResumePreparedCopies) {
 $saved=Get-Content -LiteralPath "$audit/initialization.json" -Raw|ConvertFrom-Json
 if($saved.status -ne 'preparing' -or $saved.restoredCopies.Count -ne 3){throw 'Only the recorded pre-initialization preparation can resume.'}
 $run=$saved.runId;$private=$saved.privateRoot
 $report=[ordered]@{format=$saved.format;runId=$run;atUtc=$saved.atUtc;privateRoot=$private;actualSourceOrTargetMutated=$false;restoredCopies=@($saved.restoredCopies);status='preparing';preparationDiagnostic='Initial configuration preparation rejected legacy connection keyword aliases before launching initializer; existing three copies reused.'}
 $map=@{};foreach($item in $saved.restoredCopies){$map[$item.sourceDatabase]=$item.database}
}else{
$run=[guid]::NewGuid().ToString('N')
$private="D:/CP6-local-publish/20260915/private/c04a-initialize-$run"
[void](New-Item -ItemType Directory -Path $private -ErrorAction Stop)
$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
& icacls $private /inheritance:r /grant:r "*$($sid):(OI)(CI)F" '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F'|Out-Null
if($LASTEXITCODE -ne 0){throw 'Private directory ACL failed.'}
$report=[ordered]@{format='CP6.C04A.RestoredInitialization.v1';runId=$run;atUtc=[DateTimeOffset]::UtcNow.ToString('O');privateRoot=$private;actualSourceOrTargetMutated=$false;restoredCopies=@();status='preparing'}
Save-Json 'initialization.json' $report
$map=@{}
foreach($item in @($recovery.items|Where-Object role -in @('auth-identity-catalog','business-primary','business-isolation'))) {
 if($item.status -ne 'passed' -or (Hash-File $item.backupPath) -ne $item.backupSha256){throw 'Backup bytes unavailable or changed.'}
 $c=Open-Sql 'native' 'master'
 try {
  $name='CP6_C04A_Init_'+$run.Substring(0,12)+'_'+$item.role.Replace('-','_')
  if((Query $c "SELECT database_id FROM sys.databases WHERE name=$(Sql-Text $name);").Rows.Count -ne 0){throw 'Restore target exists.'}
  $files=Rows (Query $c "RESTORE FILELISTONLY FROM DISK=$(Sql-Text $item.backupPath);")
  $moves=@();$paths=@()
  foreach($f in $files) {
   if($f.Type -notin @('D','L')){throw 'Unsupported file type.'}
   $folder=if($f.Type -eq 'L'){$item.source.logPath}else{$item.source.dataPath}
   $extension=if($f.Type -eq 'L'){'.ldf'}else{'.mdf'}
   $path=Join-Path $folder ($name+'_'+$f.FileId+$extension)
   if(Test-Path -LiteralPath $path){throw 'Restore destination exists.'}
   $moves += 'MOVE '+(Sql-Text $f.LogicalName)+' TO '+(Sql-Text $path);$paths += $path
  }
  $report.restoredCopies += [ordered]@{role=$item.role;database=$name;sourceBackupSha256=$item.backupSha256;sourceDatabase=$item.source.databaseName;physicalFiles=$paths}
  Save-Json 'initialization.json' $report
  Exec-Sql $c ("RESTORE DATABASE $(Sql-Id $name) FROM DISK=$(Sql-Text $item.backupPath) WITH CHECKSUM,RECOVERY,RESTRICTED_USER,"+($moves -join ',')+';')
  $map[$item.source.databaseName]=$name
 }finally{$c.Dispose()}
}
}
if($map.Count -ne 3){throw 'Incomplete restored copy set.'}
$original='D:/CP6-local-publish/20260910/private/c02-8cab2139bf194595a8a1812874c5bdee/crm-content/appsettings.json'
$config=Get-Content -LiteralPath $original -Raw|ConvertFrom-Json
$script:rebound=0
function Rebind($obj) {
 foreach($property in @($obj.PSObject.Properties)) {
  if($property.Value -is [string] -and $property.Name -match 'connectionString$' -and ![string]::IsNullOrWhiteSpace($property.Value)) {
   $b=New-Object System.Data.SqlClient.SqlConnectionStringBuilder
   $g=New-Object System.Data.Common.DbConnectionStringBuilder
   $g.set_ConnectionString($property.Value)
   foreach($key in @($g.get_Keys())){$k=switch($key.ToLowerInvariant()){'multiple active result sets' {'MultipleActiveResultSets'} 'trust server certificate' {'TrustServerCertificate'} default {$key}};$b[$k]=$g[$key]}
   $catalog=$b.get_InitialCatalog()
   if(!$map.ContainsKey($catalog)){throw 'Unmapped SQL database in configuration.'}
   $b.set_InitialCatalog($map[$catalog]);$b.set_DataSource('lpc:localhost\KOUSQLSERVER')
   $property.Value=$b.get_ConnectionString();$script:rebound++
  }elseif($property.Value -is [System.Management.Automation.PSCustomObject]){Rebind $property.Value}
  elseif($property.Value -is [array]){foreach($v in $property.Value){if($v -is [System.Management.Automation.PSCustomObject]){Rebind $v}}}
 }
}
Rebind $config
if($script:rebound -ne 4){throw "Unexpected SQL reference count: $script:rebound"}
$content=Join-Path $private 'crm-content';$keys=Join-Path $private 'crm-keys'
[void](New-Item -ItemType Directory -Path $content,$keys -ErrorAction Stop)
$keyHashes=@()
foreach($f in Get-ChildItem -LiteralPath $config.crmAuth.dataProtectionKeyPath -File){$dest=Join-Path $keys $f.Name;[IO.File]::Copy($f.FullName,$dest,$false);$hash=Hash-File $f.FullName;if((Hash-File $dest) -ne $hash){throw 'Key copy mismatch.'};$keyHashes += [ordered]@{file=$f.Name;sha256=$hash}}
$config.crmAuth.dataProtectionKeyPath=$keys
$configPath=Join-Path $content 'appsettings.json'
$config|ConvertTo-Json -Depth 30|Set-Content -LiteralPath $configPath -Encoding utf8
$report['configuration']=[ordered]@{originalPath=$original;originalSha256=(Hash-File $original);isolatedPath=$configPath;isolatedSha256=(Hash-File $configPath);sqlReferencesRebound=$script:rebound;keyFiles=$keyHashes;keyProtectionApplication='CP6.CRM';httpEndpointsBoundByInitialization=$false}
$pub=(Get-Content -LiteralPath 'D:/CP6-audit-results/20260914/local-execution-package/publication-manifest.json' -Raw|ConvertFrom-Json).publications.api
$actual=@(Get-ChildItem -LiteralPath $pub.directory -File -Recurse)
if($actual.Count -ne $pub.fileCount){throw 'API package file count changed.'}
$handles=@()
try {
 foreach($f in $pub.files) {
  $path=Join-Path $pub.directory $f.path
  $stream=[IO.File]::Open($path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
  $handles += $stream
  if((Hash-File $path) -ne $f.sha256){throw 'API package bytes changed.'}
 }
 $dotnet=(Get-Command dotnet).Source
 $report['apiPackage']=[ordered]@{directory=$pub.directory;sourceCommit=$pub.sourceCommit;fileCount=$pub.fileCount;fileSetSha256=$pub.fileSetSha256;dotnetPath=$dotnet;dotnetSha256=(Hash-File $dotnet)}
 $report.status='initializing';Save-Json 'initialization.json' $report
 $si=[Diagnostics.ProcessStartInfo]::new($dotnet);$si.UseShellExecute=$false;$si.CreateNoWindow=$true;$si.RedirectStandardOutput=$true;$si.RedirectStandardError=$true;$si.WorkingDirectory=$content
 foreach($arg in @((Join-Path $pub.directory 'CP6.CRM.Api.dll'),'--contentRoot',$content,'--initialize-crm')){$si.ArgumentList.Add($arg)}
 $si.Environment.Clear()
 foreach($key in @('PATH','SystemRoot','WINDIR','TEMP','TMP','USERPROFILE','APPDATA','LOCALAPPDATA','ProgramFiles','ProgramFiles(x86)','DOTNET_ROOT')){if([Environment]::GetEnvironmentVariable($key)){$si.Environment[$key]=[Environment]::GetEnvironmentVariable($key)}}
 $si.Environment['ASPNETCORE_ENVIRONMENT']='Development';$si.Environment['DOTNET_CLI_USE_MSBUILD_SERVER']='0'
 $process=[Diagnostics.Process]::Start($si)
 $out=$process.StandardOutput.ReadToEndAsync();$err=$process.StandardError.ReadToEndAsync();$watch=[Diagnostics.Stopwatch]::StartNew()
 if(!$process.WaitForExit(180000)){$process.Kill($true);$process.WaitForExit();throw 'Owned initializer timed out.'}
 [IO.File]::WriteAllText((Join-Path $private 'initialize.stdout.log'),$out.GetAwaiter().GetResult());[IO.File]::WriteAllText((Join-Path $private 'initialize.stderr.log'),$err.GetAwaiter().GetResult())
 $report['execution']=[ordered]@{exitCode=$process.ExitCode;seconds=[math]::Round($watch.Elapsed.TotalSeconds,3);stdoutSha256=(Hash-File (Join-Path $private 'initialize.stdout.log'));stderrSha256=(Hash-File (Join-Path $private 'initialize.stderr.log'))}
 $report.status=if($process.ExitCode -eq 0){'initialized-awaiting-database-inspection'}else{'initialization-failed'}
 Save-Json 'initialization.json' $report
 Write-Output "Isolated actual-restore initializer exit=$($process.ExitCode); copies=$($map.Count); SQL refs=$script:rebound; seconds=$($report.execution.seconds)"
 if($process.ExitCode -ne 0){exit 1}
}finally{foreach($h in $handles){$h.Dispose()}}
