. 'D:/CP6-audit-results/20260915/six-db-recovery/common.ps1'
$audit='D:/CP6-audit-results/20260915/restored-initialization'
$r=Get-Content -LiteralPath "$audit/initialization.json" -Raw|ConvertFrom-Json
$inspect=Get-Content -LiteralPath "$audit/initialized-inspection.json" -Raw|ConvertFrom-Json
if($r.execution.exitCode -ne 0 -or $inspect.targets.Count -ne 2){throw 'Initialization evidence missing.'}
$config=Get-Content -LiteralPath $r.configuration.isolatedPath -Raw|ConvertFrom-Json
$issuerHold=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0);$issuerHold.Start()
$portHold=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0);$portHold.Start();$port=$portHold.LocalEndpoint.Port
$config.crmAuth.issuer='https://127.0.0.1:'+$issuerHold.LocalEndpoint.Port
# The deliberately unavailable issuer is held locally: no credentials or callbacks reach the original environment.
$config.kestrel=[pscustomobject]@{endpoints=[pscustomobject]@{isolated=[pscustomobject]@{url="http://127.0.0.1:$port"}}}
$content=Join-Path $r.privateRoot 'startup-content'
[void](New-Item -ItemType Directory -Path $content -ErrorAction Stop)
$config|ConvertTo-Json -Depth 30|Set-Content -LiteralPath (Join-Path $content 'appsettings.json') -Encoding utf8
$si=[Diagnostics.ProcessStartInfo]::new($r.apiPackage.dotnetPath);$si.UseShellExecute=$false;$si.CreateNoWindow=$true;$si.RedirectStandardOutput=$true;$si.RedirectStandardError=$true;$si.WorkingDirectory=$content
foreach($arg in @((Join-Path $r.apiPackage.directory 'CP6.CRM.Api.dll'),'--contentRoot',$content)){$si.ArgumentList.Add($arg)}
$si.Environment.Clear()
foreach($key in @('PATH','SystemRoot','WINDIR','TEMP','TMP','USERPROFILE','APPDATA','LOCALAPPDATA','ProgramFiles','ProgramFiles(x86)','DOTNET_ROOT')){if([Environment]::GetEnvironmentVariable($key)){$si.Environment[$key]=[Environment]::GetEnvironmentVariable($key)}}
$si.Environment['ASPNETCORE_ENVIRONMENT']='Development'
$process=$null;$client=[Net.Http.HttpClient]::new();$client.Timeout=[TimeSpan]::FromSeconds(3)
$report=[ordered]@{format='CP6.C04A.RestoredClosedStartup.v1';atUtc=[DateTimeOffset]::UtcNow.ToString('O');scope='Restored native databases; isolated loopback API; unavailable isolated issuer';actualEnvironmentChanged=$false;identityReconciliationOrLoginProven=$false;fullRecoveryHostProven=$false;initialCalendarStored=$false;apiSourceCommit=$r.apiPackage.sourceCommit;port=$port;status='running'}
try {
 $portHold.Stop();$process=[Diagnostics.Process]::Start($si);$started=$process.StartTime.ToUniversalTime().Ticks
 $out=$process.StandardOutput.ReadToEndAsync();$err=$process.StandardError.ReadToEndAsync()
 $deadline=[DateTime]::UtcNow.AddSeconds(30);$live=$null
 while([DateTime]::UtcNow -lt $deadline) {
  if($process.HasExited){throw 'Owned API exited before liveness.'}
  try {$response=$client.GetAsync("http://127.0.0.1:$port/health/live").GetAwaiter().GetResult();$live=[int]$response.StatusCode;$response.Dispose();if($live -eq 200){break}}catch [Net.Http.HttpRequestException]{}
  Start-Sleep -Milliseconds 200
 }
 if($live -ne 200){throw 'Liveness did not pass.'}
 $response=$client.GetAsync("http://127.0.0.1:$port/health/ready").GetAwaiter().GetResult();$ready=[int]$response.StatusCode;$response.Dispose()
 if($ready -ne 503){throw 'Closed database unexpectedly reported ready.'}
 $report['http']=[ordered]@{live=$live;ready=$ready;expectedReady=503};$report.status='passed'
}finally{
 if($process){if(!$process.HasExited){if($process.StartTime.ToUniversalTime().Ticks -ne $started){throw 'Owned API process identity changed.'};$process.Kill($true);$process.WaitForExit()};[IO.File]::WriteAllText((Join-Path $r.privateRoot 'startup.stdout.log'),$out.GetAwaiter().GetResult());[IO.File]::WriteAllText((Join-Path $r.privateRoot 'startup.stderr.log'),$err.GetAwaiter().GetResult());$report['ownedProcessExited']=$process.HasExited;$process.Dispose()}
 $portHold.Stop();$issuerHold.Stop();$client.Dispose()
 Save-Json 'closed-startup.json' $report
}
$states=@()
foreach($item in $inspect.targets){$c=Open-Sql 'native' $item.database;try{$state=Rows (Query $c 'SELECT State,Generation FROM crm_cutover.Control;');if($state[0].State -ne 'Closed' -or $state[0].Generation -ne 0){throw 'Target gate changed during startup.'};$states += [ordered]@{role=$item.role;state=$state[0]}}finally{$c.Dispose()}}
$report['gateStatesAfter']=$states;Save-Json 'closed-startup.json' $report
Write-Output "Restored API startup: live=200, ready=503 as required for Closed; both gates unchanged; owned API stopped."
