. "$PSScriptRoot/common.ps1"
$report=Get-Content -LiteralPath "$audit/recovery-report.json" -Raw|ConvertFrom-Json
$root=$report.privateRoot
$controlPath='D:/CP6-local-publish/20260910/preview-control.json'
$control=Get-Content -LiteralPath $controlPath -Raw|ConvertFrom-Json
$manifest=Get-Content -LiteralPath $control.manifestPath -Raw|ConvertFrom-Json
$configPath=Join-Path $control.privateRoot 'crm-content/appsettings.json'
$config=Get-Content -LiteralPath $configPath -Raw|ConvertFrom-Json
$fixture=Get-Content -LiteralPath $manifest.fixturePath -Raw|ConvertFrom-Json
$files=@($controlPath,$control.manifestPath,$manifest.fixturePath,$configPath,$manifest.certificatePath)
if($config.crmAuth.dataProtectionCertificatePath){$files += $config.crmAuth.dataProtectionCertificatePath}
$files += @(Get-ChildItem -LiteralPath $config.crmAuth.dataProtectionKeyPath -File -Recurse|Select-Object -ExpandProperty FullName)
$files += @(Get-ChildItem -LiteralPath $fixture.coreContentRoot -Filter appsettings*.json -File|Select-Object -ExpandProperty FullName)
$files += 'D:/CP6-local-publish/20260910/start-preview.ps1','D:/CP6-local-publish/20260910/stop-preview.ps1'
$inputs=Join-Path $root 'inputs'
[void](New-Item -ItemType Directory -Path $inputs -ErrorAction Stop)
$bindings=@();$index=0
foreach($path in @($files|Sort-Object -Unique)) {
 $index++;$dest=Join-Path $inputs ($index.ToString('D2')+'-'+[IO.Path]::GetFileName($path))
 $before=Hash-File $path
 [IO.File]::Copy($path,$dest,$false)
 if((Hash-File $dest) -ne $before -or (Hash-File $path) -ne $before){throw 'Input copy hash mismatch.'}
 $bindings += [ordered]@{source=$path;retainedPath=$dest;sha256=$before}
}
Save-Json 'preserved-inputs.json' ([ordered]@{atUtc=[DateTimeOffset]::UtcNow.ToString('O');applicationName='CP6.CRM';originalInputsChanged=$false;privateRoot=$root;files=$bindings;keyDecryptionOrApplicationRecoveryProven=$false})
$processes=@()
foreach($role in @('preview-supervisor','preview-host','core','crm','web','dispatcher')) {
 $r=Get-Content -LiteralPath (Join-Path $control.privateRoot ($role+'-process.json')) -Raw|ConvertFrom-Json
 $p=Get-Process -Id $r.pid -ErrorAction SilentlyContinue
 $processes += [ordered]@{role=$role;recordPid=$r.pid;recordStartUtcTicks=$r.startUtcTicks;processExists=[bool]$p;sameIdentity=([bool]$p -and $p.StartTime.ToUniversalTime().Ticks -eq $r.startUtcTicks)}
}
$os=Get-CimInstance Win32_OperatingSystem
$services=@(Get-CimInstance Win32_Service|Where-Object Name -in @('MSSQL$KOUSQLSERVER','vstsagent.gaobubao.CP6-Deploy.LAPTOP-3QQ44FJS')|Select-Object Name,State,StartMode)
Save-Json 'current-lifecycle.json' ([ordered]@{atUtc=[DateTimeOffset]::UtcNow.ToString('O');bootUtc=$os.LastBootUpTime.ToUniversalTime().ToString('O');previewProcesses=$processes;services=$services;oldPidInventoryReusable=$false;existingLifecycleMutated=$false;privilegedWriterIsolationVerified=$false})
Write-Output "Preserved $($bindings.Count) private input files; original inputs unchanged; observed $(@($processes|Where-Object sameIdentity).Count) of 6 original processes."
