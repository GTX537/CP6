. "$PSScriptRoot/common.ps1"
$result=@()
$failures=@()
foreach($db in $databases) {
 $c=$null
 try {
  $c=Open-Sql $db.engine $db.name
  $identity=Rows (Query $c "SELECT CAST(SERVERPROPERTY('ServerName') AS nvarchar(256)) serverName,DB_NAME() databaseName,d.database_id,d.create_date,d.collation_name,d.compatibility_level,d.state_desc,d.is_read_only,d.service_broker_guid,r.database_guid,r.family_guid,r.recovery_fork_guid,CAST(SERVERPROPERTY('InstanceDefaultBackupPath') AS nvarchar(1024)) backupPath,CAST(SERVERPROPERTY('InstanceDefaultDataPath') AS nvarchar(1024)) dataPath,CAST(SERVERPROPERTY('InstanceDefaultLogPath') AS nvarchar(1024)) logPath FROM sys.databases d JOIN sys.database_recovery_status r ON d.database_id=r.database_id WHERE d.database_id=DB_ID();")
  $files=Rows (Query $c 'SELECT file_id,name,type_desc,size,physical_name FROM sys.database_files ORDER BY file_id;')
  $tables=Rows (Query $c 'SELECT s.name schemaName,t.name tableName,SUM(p.rows) approximateRows FROM sys.tables t JOIN sys.schemas s ON s.schema_id=t.schema_id JOIN sys.partitions p ON p.object_id=t.object_id AND p.index_id IN (0,1) GROUP BY s.name,t.name ORDER BY s.name,t.name;')
  $result += [ordered]@{role=$db.role;engine=$db.engine;identity=$identity[0];files=$files;tables=$tables}
  Write-Output "$($db.role): connected; tables=$($tables.Count)"
 } catch { $failures += [ordered]@{role=$db.role;type=$_.Exception.GetType().FullName;reason=if($db.engine -eq 'docker'){'Bound Docker engine/database unavailable'}else{'SQL observation failed'}}; Write-Output "$($db.role): unavailable; recorded" } finally {if($c){$c.Dispose()}}
}
Save-Json 'database-observation.json' ([ordered]@{atUtc=[DateTimeOffset]::UtcNow.ToString('O');readOnly=$true;databases=$result;failures=$failures})
