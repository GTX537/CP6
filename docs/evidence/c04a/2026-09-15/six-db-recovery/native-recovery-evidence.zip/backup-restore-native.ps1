. "$PSScriptRoot/common.ps1"
$observation=Get-Content -LiteralPath "$audit/database-observation.json" -Raw|ConvertFrom-Json
$run=[guid]::NewGuid().ToString('N')
$private="D:/CP6-local-publish/20260915/private/c04a-recovery-$run"
[void](New-Item -ItemType Directory -Path $private -ErrorAction Stop)
$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
& icacls $private /inheritance:r /grant:r "*$($sid):(OI)(CI)F" '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null
if($LASTEXITCODE -ne 0){throw 'Private backup directory ACL failed.'}
$report=[ordered]@{format='CP6.C04A.ActualRecoveryPreparation.v1';runId=$run;startedAtUtc=[DateTimeOffset]::UtcNow.ToString('O');privateRoot=$private;sourceDatabaseMutations=$false;existingServicesStarted=$false;actualActivation=$false;productionDeployment=$false;items=@();status='running'}
Save-Json 'recovery-report.json' $report
foreach($observed in @($observation.databases|Where-Object engine -eq 'native')) {
 $c=$null;$restored=$null;$item=[ordered]@{role=$observed.role;engine='native';source=$observed.identity;status='pending'}
 $report.items += $item
 try {
  $c=Open-Sql 'native' 'master'
  $name=$observed.identity.databaseName;$qname=Sql-Id $name
  $current=Rows (Query $c "SELECT d.name,r.database_guid,r.family_guid FROM sys.databases d JOIN sys.database_recovery_status r ON r.database_id=d.database_id WHERE d.name=$(Sql-Text $name);")
  if($current.Count -ne 1 -or $current[0].database_guid.ToString() -ne $observed.identity.database_guid){throw 'Source identity changed.'}
  $copyName='CP6_C04A_Prep_'+$run.Substring(0,12)+'_'+$observed.role.Replace('-','_')
  $backup=Join-Path $observed.identity.backupPath ($copyName+'.bak')
  if(Test-Path -LiteralPath $backup){throw 'Backup already exists; overwrite prohibited.'}
  $existing=Query $c "SELECT database_id FROM sys.databases WHERE name=$(Sql-Text $copyName);"
  if($existing.Rows.Count -ne 0){throw 'Restore database already exists.'}
  $item['backupPath']=$backup;$item['restoreDatabase']=$copyName
  Save-Json 'recovery-report.json' $report
  $sw=[Diagnostics.Stopwatch]::StartNew()
  Exec-Sql $c "BACKUP DATABASE $qname TO DISK=$(Sql-Text $backup) WITH COPY_ONLY,CHECKSUM,NOINIT,NAME=$(Sql-Text $copyName),BUFFERCOUNT=4,MAXTRANSFERSIZE=1048576;"
  $item['backupSeconds']=[math]::Round($sw.Elapsed.TotalSeconds,3)
  Exec-Sql $c "RESTORE VERIFYONLY FROM DISK=$(Sql-Text $backup) WITH CHECKSUM;"
  $header=Rows (Query $c "RESTORE HEADERONLY FROM DISK=$(Sql-Text $backup);")
  if($header.Count -ne 1 -or !$header[0].IsCopyOnly -or !$header[0].HasBackupChecksums -or $header[0].DatabaseName -ne $name -or $header[0].FamilyGUID.ToString() -ne $observed.identity.family_guid){throw 'Backup header binding failed.'}
  $item['backupHeader']=[ordered]@{databaseName=$header[0].DatabaseName;backupSetGuid=$header[0].BackupSetGUID;familyGuid=$header[0].FamilyGUID;firstLsn=$header[0].FirstLSN;lastLsn=$header[0].LastLSN;checkpointLsn=$header[0].CheckpointLSN;start=$header[0].BackupStartDate;finish=$header[0].BackupFinishDate;copyOnly=$header[0].IsCopyOnly;checksums=$header[0].HasBackupChecksums}
  $item['backupSha256']=Hash-File $backup
  $retained=Join-Path $private ($copyName+'.bak')
  if(Test-Path -LiteralPath $retained){throw 'Retained backup exists.'}
  [IO.File]::Copy($backup,$retained,$false)
  if((Hash-File $retained) -ne $item.backupSha256){throw 'Retained backup hash differs.'}
  $item['retainedBackupPath']=$retained
  $filelist=Rows (Query $c "RESTORE FILELISTONLY FROM DISK=$(Sql-Text $backup);")
  $moves=@();$destinations=@()
  foreach($f in $filelist) {
   if($f.Type -notin @('D','L')){throw 'Unsupported restore file type.'}
   $folder=if($f.Type -eq 'L'){$observed.identity.logPath}else{$observed.identity.dataPath}
   $extension=if($f.Type -eq 'L'){'.ldf'}else{'.mdf'}
   $dest=Join-Path $folder ($copyName+'_'+$f.FileId+$extension)
   if(Test-Path -LiteralPath $dest){throw 'Restore destination exists.'}
   $destinations += [ordered]@{logicalName=$f.LogicalName;type=$f.Type;path=$dest}
   $moves += 'MOVE '+(Sql-Text $f.LogicalName)+' TO '+(Sql-Text $dest)
  }
  $item['restoreFiles']=$destinations
  Save-Json 'recovery-report.json' $report
  $sw.Restart()
  Exec-Sql $c ("RESTORE DATABASE $(Sql-Id $copyName) FROM DISK=$(Sql-Text $backup) WITH CHECKSUM,RECOVERY,RESTRICTED_USER,"+($moves -join ',')+';')
  $item['restoreSeconds']=[math]::Round($sw.Elapsed.TotalSeconds,3)
  Exec-Sql $c "ALTER DATABASE $(Sql-Id $copyName) SET READ_ONLY;"
  $restored=Open-Sql 'native' $copyName
  $dbcc=Rows (Query $restored 'DBCC CHECKDB WITH NO_INFOMSGS,ALL_ERRORMSGS,TABLERESULTS,MAXDOP=1;' 300)
  if($dbcc.Count -ne 0){throw 'Restored database CHECKDB returned errors.'}
  $tables=Rows (Query $restored 'SELECT s.name schemaName,t.name tableName FROM sys.tables t JOIN sys.schemas s ON s.schema_id=t.schema_id ORDER BY s.name,t.name;')
  $counts=@()
  foreach($t in $tables){$n=Query $restored "SELECT COUNT_BIG(*) n FROM $(Sql-Id $t.schemaName).$(Sql-Id $t.tableName);";$counts += [ordered]@{schema=$t.schemaName;table=$t.tableName;rows=[long]$n.Rows[0]['n']}}
  $state=Rows (Query $restored "SELECT DB_NAME() databaseName,d.state_desc,d.is_read_only,d.user_access_desc,r.family_guid FROM sys.databases d JOIN sys.database_recovery_status r ON r.database_id=d.database_id WHERE d.database_id=DB_ID();")
  if(!$state[0].is_read_only -or $state[0].state_desc -ne 'ONLINE' -or $state[0].family_guid.ToString() -ne $observed.identity.family_guid){throw 'Restored database state/family mismatch.'}
  $item['restoredState']=$state[0];$item['readCounts']=$counts;$item['checkDb']='passed';$item['allUserTablesReadable']=$true;$item['status']='passed'
  Write-Output "$($item.role): backup + VERIFYONLY + restore + CHECKDB + $($counts.Count) table reads passed"
 } catch {
  $item['status']='failed';$item['failureType']=$_.Exception.GetType().FullName
  $item['failureMessage']=$_.Exception.Message
  $report.status='failed';Save-Json 'recovery-report.json' $report
  throw "Recovery preparation failed for $($item.role); see local evidence."
 } finally {if($restored){$restored.Dispose()};if($c){$c.Dispose()};Save-Json 'recovery-report.json' $report}
}
$report.status='five-native-passed-docker-unavailable';$report['finishedAtUtc']=[DateTimeOffset]::UtcNow.ToString('O')
Save-Json 'recovery-report.json' $report
