. "$PSScriptRoot/common.ps1"
$report=Get-Content -LiteralPath "$audit/recovery-report.json" -Raw|ConvertFrom-Json
$input=Get-Content -LiteralPath "$audit/preserved-inputs.json" -Raw|ConvertFrom-Json
$schemaSql=@'
SELECT (
 SELECT s.name [schema],o.name,o.type,
 (SELECT c.column_id,c.name,ty.name typeName,c.max_length,c.precision,c.scale,c.is_nullable,c.is_identity,c.is_computed,c.collation_name FROM sys.columns c JOIN sys.types ty ON ty.user_type_id=c.user_type_id WHERE c.object_id=o.object_id ORDER BY c.column_id FOR JSON PATH) columnsJson,
 (SELECT i.name,i.type,i.is_unique,i.is_primary_key,i.has_filter,i.filter_definition,(SELECT ic.key_ordinal,ic.index_column_id,ic.column_id,ic.is_descending_key,ic.is_included_column FROM sys.index_columns ic WHERE ic.object_id=i.object_id AND ic.index_id=i.index_id ORDER BY ic.index_column_id FOR JSON PATH) cols FROM sys.indexes i WHERE i.object_id=o.object_id ORDER BY i.index_id FOR JSON PATH) indexesJson,
 (SELECT fk.name,fk.is_disabled,fk.is_not_trusted,fk.delete_referential_action,fk.update_referential_action,(SELECT fkc.constraint_column_id,fkc.parent_column_id,OBJECT_SCHEMA_NAME(fkc.referenced_object_id) refSchema,OBJECT_NAME(fkc.referenced_object_id) refTable,fkc.referenced_column_id FROM sys.foreign_key_columns fkc WHERE fkc.constraint_object_id=fk.object_id ORDER BY fkc.constraint_column_id FOR JSON PATH) cols FROM sys.foreign_keys fk WHERE fk.parent_object_id=o.object_id ORDER BY fk.name FOR JSON PATH) foreignKeysJson,
 (SELECT d.name,d.parent_column_id,d.definition FROM sys.default_constraints d WHERE d.parent_object_id=o.object_id ORDER BY d.name FOR JSON PATH) defaultsJson,
 (SELECT cc.name,cc.definition,cc.is_disabled,cc.is_not_trusted FROM sys.check_constraints cc WHERE cc.parent_object_id=o.object_id ORDER BY cc.name FOR JSON PATH) checksJson,
 (SELECT tr.name,tr.is_disabled,m.definition FROM sys.triggers tr LEFT JOIN sys.sql_modules m ON m.object_id=tr.object_id WHERE tr.parent_id=o.object_id ORDER BY tr.name FOR JSON PATH) triggersJson,
 m.definition
 FROM sys.objects o JOIN sys.schemas s ON s.schema_id=o.schema_id LEFT JOIN sys.sql_modules m ON m.object_id=o.object_id
 WHERE o.is_ms_shipped=0 AND o.type IN ('U','V','P','FN','IF','TF')
 ORDER BY s.name,o.name,o.type FOR JSON PATH
) schemaJson;
'@
function Digest([string]$s){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($s))).ToLowerInvariant()}
$items=@()
foreach($i in $report.items) {
 if($i.status -ne 'passed'){throw 'Incomplete backup evidence.'}
 foreach($path in @($i.backupPath,$i.retainedBackupPath)){if((Hash-File $path) -ne $i.backupSha256){throw 'Retained backup bytes changed.'}}
 $source=$null;$copy=$null
 try {
  $source=Open-Sql $i.engine $i.source.databaseName
  $copy=Open-Sql $i.engine $i.restoreDatabase
  $a=Query $source $schemaSql;$b=Query $copy $schemaSql
  $sourceHash=Digest ([string]$a.Rows[0][0]);$copyHash=Digest ([string]$b.Rows[0][0])
  if($sourceHash -ne $copyHash){throw 'Source and restored schema differ.'}
  $state=Rows (Query $source "SELECT d.state_desc,d.is_read_only,r.database_guid,r.family_guid,(SELECT COUNT(*) FROM sys.schemas WHERE name=N'crm_source_control') sourceControlSchemas FROM sys.databases d JOIN sys.database_recovery_status r ON d.database_id=r.database_id WHERE d.database_id=DB_ID();")
  if($state[0].database_guid.ToString() -ne $i.source.database_guid -or $state[0].is_read_only -or $state[0].state_desc -ne 'ONLINE'){throw 'Source state changed.'}
  $items += [ordered]@{role=$i.role;schemaSha256=$sourceHash;restoreSchemaMatches=$true;sourceState=$state[0];backupHashesMatch=$true;readableTableCount=$i.readCounts.Count;totalRows=($i.readCounts|Measure-Object rows -Sum).Sum}
 }finally{if($source){$source.Dispose()};if($copy){$copy.Dispose()}}
}
foreach($f in $input.files){if((Hash-File $f.source) -ne $f.sha256 -or (Hash-File $f.retainedPath) -ne $f.sha256){throw 'Private input bytes changed.'}}
Save-Json 'preservation-verification.json' ([ordered]@{atUtc=[DateTimeOffset]::UtcNow.ToString('O');items=$items;privateInputsVerified=$input.files.Count;allChecked=$true;applicationRecoveryOrKeyDecryptionProven=$false;crossDatabaseConsistentCutoverSnapshot=$false;crm11CanonicalDataComparisonPerformed=$false})
Write-Output "$($items.Count) source/restore schema digests match; all retained backup hashes and $($input.files.Count) private input copies match."
