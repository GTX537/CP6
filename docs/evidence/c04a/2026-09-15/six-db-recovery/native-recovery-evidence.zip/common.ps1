$ErrorActionPreference='Stop'
$audit='D:/CP6-audit-results/20260915/six-db-recovery'
$containerId='505a5337f99522fd483f8db86a0e1b2d3da6755ef133d1bf341af063798f368e'
$pipe='npipe:////./pipe/dockerDesktopLinuxEngine'
$databases=@(
 @{role='native-core';engine='native';name='CP6DB'},
 @{role='preview-core';engine='native';name='CP6C02Live_9d8a22de291c44cd8516a3d81888fcc3'},
 @{role='auth-identity-catalog';engine='native';name='CP6CrmC02Live_516b677f84b64cd1a876590a8cb54a0b'},
 @{role='business-primary';engine='native';name='CP6CrmC02Live_86a709a6f627426fa23ad88f7dd2ebb9'},
 @{role='business-isolation';engine='native';name='CP6CrmC02Live_4bc6bc987f8040da843caf86c0b7faf2'},
 @{role='docker-core';engine='docker';name='CP6DB'}
)
function Open-Sql([string]$engine,[string]$database='master') {
 $b=New-Object System.Data.SqlClient.SqlConnectionStringBuilder
 if($engine -eq 'native') {
  $cfg=Get-Content -LiteralPath 'D:/CP6/CP6.WebApi/appsettings.Local.json' -Raw|ConvertFrom-Json
  $g=New-Object System.Data.Common.DbConnectionStringBuilder
  $g.set_ConnectionString($cfg.ConnectionStrings.DefaultConnection)
  foreach($key in @($g.get_Keys())) {
   $k=switch($key.ToLowerInvariant()) {'multiple active result sets' {'MultipleActiveResultSets'} 'trust server certificate' {'TrustServerCertificate'} default {$key}}
   $b[$k]=$g[$key]
  }
  $b.set_DataSource('lpc:localhost\KOUSQLSERVER')
 } elseif($engine -eq 'docker') {
  $raw=docker --host $pipe inspect $containerId 2>$null
  if($LASTEXITCODE -ne 0){throw 'Bound Docker engine unavailable; no lifecycle change attempted.'}
  $c=($raw|ConvertFrom-Json)[0]
  if($c.Id -ne $containerId -or $c.Name -ne '/cp6-db' -or !$c.State.Running){throw 'Bound Docker database unavailable.'}
  $p=@($c.NetworkSettings.Ports.'1433/tcp'|Where-Object {$_.HostPort -eq '1433'})
  if($p.Count -eq 0){throw 'Bound SQL port changed.'}
  $v=@($c.Config.Env|Where-Object {$_ -match '^(MSSQL_SA_PASSWORD|SA_PASSWORD)='}|ForEach-Object {($_ -split '=',2)[1]}|Select-Object -Unique)
  if($v.Count -ne 1){throw 'Ambiguous credential reference.'}
  $b['Data Source']='127.0.0.1,1433';$b['User ID']='sa';$b['Password']=$v[0];$b['Encrypt']=$true;$b['TrustServerCertificate']=$true
 } else {throw 'Unknown engine.'}
 $b.set_InitialCatalog($database);$b['Pooling']=$false;$b['Connect Timeout']=20;$b['Application Name']='CP6-C04A-six-db-recovery-preparation'
 $c=New-Object System.Data.SqlClient.SqlConnection($b.get_ConnectionString())
 $c.Open(); return $c
}
function Query($c,[string]$sql,[int]$timeout=60) {
 $cmd=$c.CreateCommand();$cmd.CommandText=$sql;$cmd.CommandTimeout=$timeout
 $dt=New-Object System.Data.DataTable
 try {$r=$cmd.ExecuteReader();try{$dt.Load($r)}finally{$r.Dispose()}}finally{$cmd.Dispose()}
 return ,$dt
}
function Rows($table) {
 return @($table.Rows|ForEach-Object {$item=[ordered]@{};foreach($col in $table.Columns){$v=$_[$col.ColumnName];$item[$col.ColumnName]=if($v -is [DBNull]){$null}else{$v}};[pscustomobject]$item})
}
function Exec-Sql($c,[string]$sql,[int]$timeout=300) {
 $cmd=$c.CreateCommand();$cmd.CommandText=$sql;$cmd.CommandTimeout=$timeout
 try{[void]$cmd.ExecuteNonQuery()}finally{$cmd.Dispose()}
}
function Sql-Id([string]$s){'['+$s.Replace(']',']]')+']'}
function Sql-Text([string]$s){"N'"+$s.Replace("'","''")+"'"}
function Hash-File([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Save-Json([string]$name,$value){$value|ConvertTo-Json -Depth 30|Set-Content -LiteralPath (Join-Path $audit $name) -Encoding utf8}
