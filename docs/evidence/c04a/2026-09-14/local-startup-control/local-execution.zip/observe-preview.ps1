param([ValidateSet('before','after')][string]$Phase)
$ErrorActionPreference='Stop'
$publication='D:/CP6-local-publish/20260910'
$controlPath=Join-Path $publication 'preview-control.json'
$control=Get-Content -LiteralPath $controlPath -Raw | ConvertFrom-Json
$processes=@()
foreach($name in @('preview-supervisor','preview-host','core','crm','dispatcher','web')) {
  $record=Get-Content -LiteralPath (Join-Path $control.privateRoot ($name+'-process.json')) -Raw | ConvertFrom-Json
  $process=Get-Process -Id $record.pid -ErrorAction Stop
  $ticks=$process.StartTime.ToUniversalTime().Ticks
  if($ticks -ne $record.startUtcTicks){throw 'Preview process ownership differs; no action performed.'}
  $processes += [ordered]@{name=$name;pid=$process.Id;startUtcTicks=$ticks}
}
$files=[ordered]@{}
foreach($path in @('preview-control.json','start-preview.ps1','stop-preview.ps1','recovery/run-preview.ps1','recovery/bin/Release/net8.0/PreviewHost.dll','crm-api/CP6.CRM.Api.dll','recovery/bin/Release/net8.0/CP6.CRM.Api.dll','harness/bin/Release/net8.0/CP6.CRM.Api.dll')) {
  $files[$path]=(Get-FileHash -LiteralPath (Join-Path $publication $path) -Algorithm SHA256).Hash.ToLowerInvariant()
}
$result=[ordered]@{atUtc=[DateTimeOffset]::UtcNow.ToString('O');processes=$processes;files=$files;readOnly=$true}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath ('D:/CP6-audit-results/20260914/local-startup-control/preview-'+$Phase+'.json')
[ordered]@{phase=$Phase;runningOwnedProcesses=$processes.Count;hashedFiles=$files.Count;readOnly=$true} | ConvertTo-Json -Compress
