param([string]$Attempt='cross-green-01',[string]$Filter='FullyQualifiedName~CutoverRecoveryCliTests')
$ErrorActionPreference='Stop'
$config=Get-Content -LiteralPath D:/CP6/CP6.WebApi/appsettings.Local.json -Raw | ConvertFrom-Json
$builder=New-Object System.Data.Common.DbConnectionStringBuilder
$builder.set_ConnectionString($config.ConnectionStrings.DefaultConnection)
foreach($key in @($builder.get_Keys())) { if($key -in @('Database','Initial Catalog','Server','Data Source')) { [void]$builder.Remove($key) } }
$builder['Initial Catalog']='master'
$builder['Data Source']='lpc:localhost\KOUSQLSERVER'
$env:CP6_CRM_TEST_SQL=$builder.get_ConnectionString()
$env:C04A_CORE_PUBLISHED_CLI='D:/CP6-local-publish/20260914/c04a-cutover-recovery/core/CP6.Crm.SourceFence.dll'
$env:C04A_CRM_PUBLISHED_CLI='D:/CP6-local-publish/20260914/c04a-cutover-recovery/crm/Crm.CandidateAdoption.dll'
$env:DOTNET_CLI_USE_MSBUILD_SERVER='0'
try {
 dotnet test eng/c04a/CP6.CRM.CutoverRecovery.Tests.csproj -c Release --no-build --no-restore --artifacts-path D:/CP6-audit-results/20260914/cutover-recovery/crm-artifacts --filter $Filter --logger "trx;LogFileName=$Attempt.trx" --results-directory D:/CP6-audit-results/20260914/cutover-recovery/results *> "D:/CP6-audit-results/20260914/cutover-recovery/$Attempt.log"
 $result=$LASTEXITCODE
 Get-Content -LiteralPath "D:/CP6-audit-results/20260914/cutover-recovery/$Attempt.log" -Tail 55
 exit $result
} finally { Remove-Item Env:CP6_CRM_TEST_SQL,Env:C04A_CORE_PUBLISHED_CLI,Env:C04A_CRM_PUBLISHED_CLI }
