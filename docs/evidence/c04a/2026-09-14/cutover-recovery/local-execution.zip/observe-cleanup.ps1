$ErrorActionPreference='Stop'
$config=Get-Content -LiteralPath D:/CP6/CP6.WebApi/appsettings.Local.json -Raw | ConvertFrom-Json
$generic=New-Object System.Data.Common.DbConnectionStringBuilder
$generic.set_ConnectionString($config.ConnectionStrings.DefaultConnection)
$sqlBuilder=New-Object System.Data.SqlClient.SqlConnectionStringBuilder
foreach($key in @($generic.get_Keys())) {
  $sqlKey=switch($key.ToLowerInvariant()) {
    'multiple active result sets' {'MultipleActiveResultSets'}
    'trust server certificate' {'TrustServerCertificate'}
    default {$key}
  }
  $sqlBuilder[$sqlKey]=$generic[$key]
}
$sqlBuilder.set_DataSource('lpc:localhost\KOUSQLSERVER')
$sqlBuilder.set_InitialCatalog('master')
$connection=New-Object System.Data.SqlClient.SqlConnection($sqlBuilder.get_ConnectionString())
try {
  $connection.Open()
  $command=$connection.CreateCommand()
  $command.CommandText="SELECT (SELECT COUNT(*) FROM sys.databases WHERE name LIKE N'CP6[_]C04A[_]Recovery[_]Test[_]%' OR name LIKE N'CP6[_]C04A[_]Inspection[_]Test[_]%' OR name LIKE N'CP6[_]CRM[_]BusinessTest[_]%') AS RemainingTestDatabases, (SELECT COUNT(*) FROM CP6DB.sys.schemas WHERE name=N'crm_source_control') AS ActualSourceControlSchemas;"
  $reader=$command.ExecuteReader()
  [void]$reader.Read()
  $result=[ordered]@{atUtc=[DateTimeOffset]::UtcNow.ToString('O');remainingTestDatabases=$reader.GetInt32(0);actualSourceControlSchemas=$reader.GetInt32(1)}
  $reader.Close()
  if($result.remainingTestDatabases -ne 0 -or $result.actualSourceControlSchemas -ne 0){throw 'Cleanup or actual-source invariant failed; inspect before proceeding.'}
  $result | ConvertTo-Json | Set-Content -LiteralPath D:/CP6-audit-results/20260914/cutover-recovery/cleanup-observation.json
  $result | ConvertTo-Json -Compress
} finally { $connection.Dispose() }
