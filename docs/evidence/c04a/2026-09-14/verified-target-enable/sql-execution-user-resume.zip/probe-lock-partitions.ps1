$ErrorActionPreference='Stop'
$config=Get-Content -LiteralPath D:/CP6/CP6.WebApi/appsettings.Local.json -Raw | ConvertFrom-Json
$generic=New-Object System.Data.Common.DbConnectionStringBuilder
$generic.set_ConnectionString($config.ConnectionStrings.DefaultConnection)
$sqlBuilder=New-Object System.Data.SqlClient.SqlConnectionStringBuilder
foreach($key in @($generic.get_Keys())) {
  $sqlKey=switch($key.ToLowerInvariant()) {
    'multiple active result sets' {'MultipleActiveResultSets'}
    'trust server certificate' {'TrustServerCertificate'}
    default {$key}
  }
  $sqlBuilder[$sqlKey]=$generic[$key]
}
$sqlBuilder.set_DataSource('lpc:localhost\KOUSQLSERVER')
$sqlBuilder.set_InitialCatalog('master')
$connection=New-Object System.Data.SqlClient.SqlConnection($sqlBuilder.get_ConnectionString())
try {
 $connection.Open();$command=$connection.CreateCommand();$command.CommandTimeout=10
 $command.CommandText="SELECT cpu_count,scheduler_count FROM sys.dm_os_sys_info;"
 $reader=$command.ExecuteReader();[void]$reader.Read();$result=[ordered]@{atUtc=[DateTimeOffset]::UtcNow.ToString('O');cpuCount=$reader.GetInt32(0);schedulerCount=$reader.GetInt32(1)};$reader.Close()
 $command.CommandText="CREATE TABLE #ActivationLockObservation(Id int NOT NULL); BEGIN TRAN; SELECT COUNT_BIG(*) FROM #ActivationLockObservation WITH(TABLOCKX,HOLDLOCK); SELECT request_mode,COUNT(*) AS entries,COUNT(DISTINCT resource_lock_partition) AS partitions FROM sys.dm_tran_locks WHERE request_session_id=@@SPID AND resource_database_id=DB_ID(N'tempdb') AND resource_type='OBJECT' AND resource_associated_entity_id=OBJECT_ID(N'tempdb..#ActivationLockObservation') GROUP BY request_mode; ROLLBACK; DROP TABLE #ActivationLockObservation;"
 $reader=$command.ExecuteReader();[void]$reader.NextResult();$locks=@();while($reader.Read()){$locks+=@{mode=$reader.GetString(0);entries=$reader.GetInt32(1);partitions=$reader.GetInt32(2)}};$reader.Close()
 $result.tableLocks=$locks
 $result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath D:/CP6-audit-results/20260914/verified-target-enable/lock-partition-probe.json
 $result | ConvertTo-Json -Depth 5 -Compress
} finally {$connection.Dispose()}