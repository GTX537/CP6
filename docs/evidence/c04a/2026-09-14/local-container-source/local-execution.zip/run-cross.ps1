param([string]$Attempt='cross-green-01',[string]$Filter='FullyQualifiedName~Published_Core_recovers_a_bound_Docker_source_while_verifying_a_native_CRM_target')
$ErrorActionPreference='Stop'
$audit='D:/CP6-audit-results/20260914/local-container-source'
$config=Get-Content -LiteralPath D:/CP6/CP6.WebApi/appsettings.Local.json -Raw | ConvertFrom-Json
$native=New-Object System.Data.Common.DbConnectionStringBuilder
$native.set_ConnectionString($config.ConnectionStrings.DefaultConnection)
foreach($key in @($native.get_Keys())){if($key -in @('Database','Initial Catalog','Server','Data Source')){[void]$native.Remove($key)}}
$native['Initial Catalog']='master';$native['Data Source']='lpc:localhost\KOUSQLSERVER'
$container=(docker --host npipe:////./pipe/dockerDesktopLinuxEngine inspect cp6-db | ConvertFrom-Json)[0]
if($LASTEXITCODE -ne 0){throw 'Container configuration unavailable.'}
$values=@($container.Config.Env | Where-Object {$_ -like 'MSSQL_SA_PASSWORD=*' -or $_ -like 'SA_PASSWORD=*'} | ForEach-Object {($_ -split '=',2)[1]} | Select-Object -Unique)
if($values.Count -ne 1){throw 'Container administrator credential is ambiguous.'}
$dockerSql=New-Object System.Data.SqlClient.SqlConnectionStringBuilder
$dockerSql['Data Source']='127.0.0.1,1433';$dockerSql['Initial Catalog']='master';$dockerSql['User ID']='sa';$dockerSql['Password']=$values[0]
$dockerSql['TrustServerCertificate']=$true;$dockerSql['Encrypt']=$true;$dockerSql['Pooling']=$false
$env:C04A_TEST_SQL_CONNECTION=$native.get_ConnectionString()
$env:C04A_CONTAINER_TEST_SQL=$dockerSql.get_ConnectionString()
$env:C04A_TEST_CONTAINER_BINDING_PATH=Join-Path $audit 'container-binding.json'
$env:CP6_CRM_TEST_SQL=$native.get_ConnectionString()
$env:C04A_CROSS_SOURCE_CONTAINER_SQL=$dockerSql.get_ConnectionString()
$env:C04A_CROSS_CONTAINER_BINDING_PATH=Join-Path $audit 'container-binding.json'
$env:C04A_CORE_PUBLISHED_CLI='D:/CP6-local-publish/20260914/c04a-local-container-source/CP6.Crm.SourceFence.dll'
$env:C04A_CRM_PUBLISHED_CLI='D:/CP6-local-publish/20260914/c04a-cutover-recovery/crm/Crm.CandidateAdoption.dll'
$env:DOTNET_CLI_USE_MSBUILD_SERVER='0'
try {
 dotnet test eng/c04a/CP6.CRM.CutoverRecovery.Tests.csproj -c Release --no-build --no-restore --artifacts-path "$audit/crm-artifacts" --filter $Filter --logger "trx;LogFileName=$Attempt.trx" --results-directory "$audit/results" *> "$audit/$Attempt.log"
 $result=$LASTEXITCODE
 Get-Content -LiteralPath "$audit/$Attempt.log" -Tail 55
 exit $result
} finally {Remove-Item Env:C04A_TEST_SQL_CONNECTION,Env:C04A_CONTAINER_TEST_SQL,Env:C04A_TEST_CONTAINER_BINDING_PATH,Env:CP6_CRM_TEST_SQL,Env:C04A_CROSS_SOURCE_CONTAINER_SQL,Env:C04A_CROSS_CONTAINER_BINDING_PATH,Env:C04A_CORE_PUBLISHED_CLI,Env:C04A_CRM_PUBLISHED_CLI}
