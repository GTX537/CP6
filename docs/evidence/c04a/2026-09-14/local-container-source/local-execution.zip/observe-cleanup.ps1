$ErrorActionPreference='Stop'
$config=Get-Content -LiteralPath D:/CP6/CP6.WebApi/appsettings.Local.json -Raw | ConvertFrom-Json
$generic=New-Object System.Data.Common.DbConnectionStringBuilder
$generic.set_ConnectionString($config.ConnectionStrings.DefaultConnection)
$sqlBuilder=New-Object System.Data.SqlClient.SqlConnectionStringBuilder
foreach($key in @($generic.get_Keys())) {
  $sqlKey=switch($key.ToLowerInvariant()) {
    'multiple active result sets' {'MultipleActiveResultSets'}
    'trust server certificate' {'TrustServerCertificate'}
    default {$key}
  }
  $sqlBuilder[$sqlKey]=$generic[$key]
}
$sqlBuilder.set_DataSource('lpc:localhost\KOUSQLSERVER')
$sqlBuilder.set_InitialCatalog('master')
$connection=New-Object System.Data.SqlClient.SqlConnection($sqlBuilder.get_ConnectionString())
try {
  $connection.Open()
  $command=$connection.CreateCommand()
  $command.CommandText="SELECT (SELECT COUNT(*) FROM sys.databases WHERE name LIKE N'CP6[_]C04A[_]Recovery[_]Test[_]%' OR name LIKE N'CP6[_]C04A[_]Inspection[_]Test[_]%' OR name LIKE N'CP6[_]CRM[_]BusinessTest[_]%') AS RemainingTestDatabases, (SELECT COUNT(*) FROM CP6DB.sys.schemas WHERE name=N'crm_source_control') AS ActualSourceControlSchemas;"
  $reader=$command.ExecuteReader()
  [void]$reader.Read()
  $result=[ordered]@{atUtc=[DateTimeOffset]::UtcNow.ToString('O');remainingTestDatabases=$reader.GetInt32(0);actualSourceControlSchemas=$reader.GetInt32(1)}
  $reader.Close()
  if($result.remainingTestDatabases -ne 0 -or $result.actualSourceControlSchemas -ne 0){throw 'Cleanup or actual-source invariant failed; inspect before proceeding.'}
  $native = $result

} finally { $connection.Dispose() }

$ErrorActionPreference='Stop'
$audit='D:/CP6-audit-results/20260914/local-container-source'
$container=(docker --host npipe:////./pipe/dockerDesktopLinuxEngine inspect cp6-db | ConvertFrom-Json)[0]
if($LASTEXITCODE -ne 0){throw 'Container configuration unavailable.'}
$values=@($container.Config.Env | Where-Object {$_ -like 'MSSQL_SA_PASSWORD=*' -or $_ -like 'SA_PASSWORD=*'} | ForEach-Object {($_ -split '=',2)[1]} | Select-Object -Unique)
if($values.Count -ne 1){throw 'Ambiguous local credential.'}
$builder=New-Object System.Data.SqlClient.SqlConnectionStringBuilder
$builder['Data Source']='127.0.0.1,1433';$builder['Initial Catalog']='CP6DB';$builder['User ID']='sa';$builder['Password']=$values[0]
$builder['TrustServerCertificate']=$true;$builder['Encrypt']=$true;$builder['Pooling']=$false

$builder.set_InitialCatalog('master')
$connection=New-Object System.Data.SqlClient.SqlConnection($builder.get_ConnectionString())
try {
  $connection.Open()
  $command=$connection.CreateCommand()
  $command.CommandText="SELECT (SELECT COUNT(*) FROM sys.databases WHERE name LIKE N'CP6[_]C04A[_]Recovery[_]Test[_]%' OR name LIKE N'CP6[_]C04A[_]Inspection[_]Test[_]%' OR name LIKE N'CP6[_]CRM[_]BusinessTest[_]%'), (SELECT COUNT(*) FROM CP6DB.sys.schemas WHERE name=N'crm_source_control');"
  $reader=$command.ExecuteReader();[void]$reader.Read()
  $docker=[ordered]@{remainingTestDatabases=$reader.GetInt32(0);actualSourceControlSchemas=$reader.GetInt32(1)}
  $reader.Close()
  if($docker.remainingTestDatabases -ne 0 -or $docker.actualSourceControlSchemas -ne 0){throw 'Docker cleanup or actual-source invariant failed.'}
} finally {$connection.Dispose()}
$result=[ordered]@{atUtc=[DateTimeOffset]::UtcNow.ToString('O');native=$native;docker=$docker;actualSourcesModified=$false}
$result | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $audit 'cleanup-observation.json')
$result | ConvertTo-Json -Depth 4 -Compress
