using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using CP6.CRM.Infrastructure.Identity.Contracts;
using static CP6.CRM.C02Acceptance.LiveEnvironment;

namespace CP6.CRM.C02Acceptance;

internal sealed class LiveScenarios(LiveEnvironment e, LiveEvidence evidence)
{
    public async Task RunAsync()
    {
        var cases = new (string Name, Func<Task> Run)[]
        {
            ("actual-browser-session-and-management", BrowserAsync),
            ("business-role-membership-permission-removal-and-department-move", BusinessAsync),
            ("actual-kafka-duplicate-out-of-order-gap-reconciliation", ReplayAsync),
            ("payload-conflict-and-cross-tenant-routing", ConflictAsync),
            ("projection-outage-and-missing-projection-recovery", ProjectionOutageAsync),
            ("source-failure-and-reconciliation-retry", SourceOutageAsync),
            ("sender-crash-after-commit-and-priority-backlog", SenderCrashAsync),
            ("receiver-crash-after-commit-before-broker-ack", ReceiverCrashAsync),
            ("actual-service-token-revocation", ServiceRevocationAsync),
            ("timed-user-disable", () => TimedAsync("user-disable")),
            ("timed-token-revocation", () => TimedAsync("token-revocation")),
            ("timed-tenant-disable", () => TimedAsync("tenant-disable"))
        };
        Require(e.Manifest.Scope is "all" or "baseline" || e.Manifest.SelectedCases.Length > 0 &&
            e.Manifest.SelectedCases.Distinct(StringComparer.Ordinal).Count() == e.Manifest.SelectedCases.Length &&
            e.Manifest.SelectedCases.All(selected => cases.Any(c => c.Name == selected)), "C02_UNKNOWN_ACCEPTANCE_SCOPE");
        foreach (var (name, action) in cases.Where(c => e.Manifest.Includes(c.Name)))
            await evidence.CaseAsync(name, action);
    }
    private async Task BrowserAsync()
    {
        using var browser = new LiveBrowser(e); await browser.LoginAsync(e.Primary, e.Primary.Scenario);
        using var other = new LiveBrowser(e); await other.LoginAsync(e.Other, e.Other.Scenario);
        await WorkspaceAsync(browser, 200); await WorkspaceAsync(other, 200);
        var metadata = await SessionMetadataAsync(browser);
        Require((Guid)metadata["TenantId"] == e.Primary.Id && (Guid)metadata["SubjectId"] == e.Primary.Scenario.Id &&
            (string)metadata["Issuer"] == e.Fixture.CoreOrigin && metadata["AuthenticationEpoch"] is Guid, "C02_REAL_SESSION_INDEX_MISMATCH");
        var jti = (string)metadata["Jti"];
        Require(await ScalarAsync<int>(e.Fixture.Connection, "SELECT COUNT(*) FROM dbo.CrmOidcGrant WHERE Id=@jti AND OrganizationId=@tenant AND SubjectId=@user AND Revoked=0",
            ("jti", Guid.Parse(jti)), ("tenant", e.Primary.Id), ("user", e.Primary.Scenario.Id)) == 1, "C02_INDEX_IS_NOT_ACTUAL_CORE_GRANT_JTI");
    }
    private async Task BusinessAsync()
    {
        using var admin = await AdministratorAsync();
        using var browser = new LiveBrowser(e); await browser.LoginAsync(e.Primary, e.Primary.Scenario);
        await CommandAsync(admin, HttpMethod.Put, "/api/pub/user-role/" + e.Primary.Scenario.Id,
            new { roleIds = new[] { 2, 3 }, primaryRoleId = 2 });
        await e.WaitInboxAsync(await e.LatestMessageAsync(e.Primary.Id, "user:" + e.Primary.Scenario.Id));
        await SetPermissionsAsync(admin, false);
        var removed = await e.LatestMessageAsync(e.Primary.Id, "permission:role:2"); await e.WaitInboxAsync(removed);
        using (var payload = JsonDocument.Parse(await ScalarAsync<string>(e.CrmConnection,
            "SELECT PayloadJson FROM crm_identity.Projection WHERE TenantId=@tenant AND AggregateId=N'permission:role:2'", ("tenant", e.Primary.Id))))
            Require(payload.RootElement.GetProperty("grants").GetArrayLength() == 0, "C02_EMPTY_PERMISSION_SNAPSHOT_NOT_APPLIED");
        using (var query = await browser.CrmAsync(HttpMethod.Get, "/api/crm/v1/leads/options")) Require(query.StatusCode == HttpStatusCode.OK, "C02_EXTRA_ROLE_QUERY_LOST");
        await CommandAsync(admin, HttpMethod.Put, "/api/pub/user-role/" + e.Primary.Scenario.Id,
            new { roleIds = Array.Empty<int>(), primaryRoleId = (int?)null });
        await e.WaitInboxAsync(await e.LatestMessageAsync(e.Primary.Id, "user:" + e.Primary.Scenario.Id));
        await WorkspaceAsync(browser, 401, 403);
        await SetPermissionsAsync(admin, true);
        await CommandAsync(admin, HttpMethod.Put, "/api/pub/user-role/" + e.Primary.Scenario.Id,
            new { roleIds = new[] { 2 }, primaryRoleId = 2 });
        await e.WaitInboxAsync(await e.LatestMessageAsync(e.Primary.Id, "permission:role:2"));
        await e.WaitInboxAsync(await e.LatestMessageAsync(e.Primary.Id, "user:" + e.Primary.Scenario.Id));
        using var restored = new LiveBrowser(e); await restored.LoginAsync(e.Primary, e.Primary.Scenario);
        await CommandAsync(admin, HttpMethod.Post, "/api/pub/dept/" + e.Primary.RootDepartmentId + "/move", new { newParentId = e.Primary.TargetDepartmentId });
        await e.WaitInboxAsync(await e.LatestMessageAsync(e.Primary.Id, "department:" + e.Primary.ChildDepartmentId));
        var path = await ScalarAsync<string>(e.CrmConnection,
            "SELECT JSON_VALUE(PayloadJson,'$.path') FROM crm_identity.Projection WHERE TenantId=@tenant AND AggregateId=@aggregate",
            ("tenant", e.Primary.Id), ("aggregate", "department:" + e.Primary.ChildDepartmentId));
        Require(path == $"/{e.Primary.TargetDepartmentId:D}/{e.Primary.RootDepartmentId:D}/{e.Primary.ChildDepartmentId:D}/", "C02_MOVED_DESCENDANT_PATH_DIFFERS");
        await WorkspaceAsync(restored, 200);
        await CommandAsync(admin, HttpMethod.Post, "/api/pub/dept/" + e.Primary.RootDepartmentId + "/move", new { newParentId = (Guid?)null });
        await e.WaitInboxAsync(await e.LatestMessageAsync(e.Primary.Id, "department:" + e.Primary.ChildDepartmentId));
    }
    private async Task ReplayAsync()
    {
        using var admin = await AdministratorAsync();
        await e.WaitQueuesAsync(); await e.Dispatcher.StopAsync();
        try
        {
            await SetScopeAsync(admin, 2); var older = await e.LatestMessageAsync(e.Primary.Id, "permission:role:2");
            await SetScopeAsync(admin, 3); var newer = await e.LatestMessageAsync(e.Primary.Id, "permission:role:2");
            Require(newer.Version == older.Version + 1, "C02_REAL_VERSION_SEQUENCE_DIFFERS");
            var gapAt = DateTimeOffset.UtcNow;
            await e.PublishAsync(newer); await e.WaitInboxAsync(newer, false);
            await e.PublishAsync(older); await e.WaitInboxAsync(older, false);
            var deliveries = e.Relay.SuccessCount(newer.MessageId); await e.PublishAsync(newer);
            await UntilAsync(() => Task.FromResult(e.Relay.SuccessCount(newer.MessageId) > deliveries), TimeSpan.FromSeconds(15), "C02_DUPLICATE_CALLBACK_MISSING");
            Require(await ScalarAsync<int>(e.CrmConnection, "SELECT Version FROM crm_identity.Projection WHERE TenantId=@tenant AND AggregateId=@aggregate",
                ("tenant", e.Primary.Id), ("aggregate", newer.AggregateId)) == newer.Version, "C02_REPLAY_REGRESSED_VERSION");
            Require(await ScalarAsync<int>(e.CrmConnection, "SELECT COUNT(*) FROM crm_identity.Cp6_InboxMessage WHERE MessageId=@id", ("id", newer.MessageId)) == 1, "C02_DUPLICATE_INBOX_ROW");
            await e.WaitReconciliationSinceAsync(e.Primary.Id, gapAt);
            evidence.Observe("gap-repair", new { automaticSourceVerification = true, sourceScheduleMutatedByTest = false });
        }
        finally { if (!e.Dispatcher.Running) e.StartDispatcher(); }
        await SetScopeAsync(admin, 1); await e.WaitInboxAsync(await e.LatestMessageAsync(e.Primary.Id, "permission:role:2"));
        using var browser = new LiveBrowser(e); await browser.LoginAsync(e.Primary, e.Primary.Scenario); await WorkspaceAsync(browser, 200);
    }
    private async Task ConflictAsync()
    {
        using var browser = new LiveBrowser(e); await browser.LoginAsync(e.Primary, e.Primary.Scenario);
        using var other = new LiveBrowser(e); await other.LoginAsync(e.Other, e.Other.Scenario);
        var message = await e.LatestMessageAsync(e.Primary.Id, "user:" + e.Primary.Scenario.Id);
        await e.WaitInboxAsync(message);
        var originalHash = await ScalarAsync<string>(e.CrmConnection, "SELECT PayloadSha256 FROM crm_identity.Projection WHERE TenantId=@tenant AND AggregateId=@aggregate",
            ("tenant", e.Primary.Id), ("aggregate", message.AggregateId));
        // Deliberately corrupted transport negative. Successful business facts always originate in Core SQL.
        var altered = JsonNode.Parse(message.Payload)!; altered["data"]!["managerId"] = Guid.NewGuid().ToString("D");
        var conflictAt = DateTimeOffset.UtcNow;
        await e.PublishAsync(message, Encoding.UTF8.GetBytes(altered.ToJsonString()));
        await UntilAsync(() => Task.FromResult(e.Relay.Outcome(message.MessageId) == "DROP"), TimeSpan.FromSeconds(15), "C02_CONFLICT_NOT_DROPPED");
        Require(await ScalarAsync<string>(e.CrmConnection, "SELECT PayloadSha256 FROM crm_identity.Projection WHERE TenantId=@tenant AND AggregateId=@aggregate",
            ("tenant", e.Primary.Id), ("aggregate", message.AggregateId)) == originalHash, "C02_CONFLICT_MUTATED_SNAPSHOT");
        using (var response = await browser.CrmAsync(HttpMethod.Get, "/api/crm/v1/workspace"))
        {
            Require(response.StatusCode == HttpStatusCode.ServiceUnavailable ||
                response.StatusCode == HttpStatusCode.OK && await e.HasReconciliationSinceAsync(e.Primary.Id, conflictAt),
                "C02_CONFLICT_GRANTED_WITHOUT_SOURCE_REPAIR");
        }
        await WorkspaceAsync(other, 200);
        Require(await ScalarAsync<int>(e.CrmConnection, "SELECT COUNT(*) FROM crm_identity.Cp6_DeadLetterRecord WHERE MessageId=@id", ("id", message.MessageId)) >= 1, "C02_CONFLICT_EVIDENCE_MISSING");
        await e.WaitReconciliationSinceAsync(e.Primary.Id, conflictAt); await WorkspaceAsync(browser, 200);
        evidence.Observe("conflict-repair", new { automaticSourceVerification = true, originalSnapshotPreserved = true });
        var crossId = Guid.NewGuid().ToString("N"); var cross = JsonNode.Parse(message.Payload)!; cross["id"] = crossId;
        await e.PublishAsync(message, Encoding.UTF8.GetBytes(cross.ToJsonString()), e.Other.Id + ":" + message.AggregateId);
        await UntilAsync(() => Task.FromResult(e.Relay.Outcome(crossId) == "DROP"), TimeSpan.FromSeconds(15), "C02_CROSS_TENANT_DELIVERY_NOT_DROPPED");
        Require(await ScalarAsync<int>(e.CrmConnection, "SELECT COUNT(*) FROM crm_identity.Cp6_InboxMessage WHERE MessageId=@id", ("id", crossId)) == 0, "C02_INVALID_ROUTE_CREATED_INBOX_STATE");
        await WorkspaceAsync(other, 200);
    }
    private async Task ProjectionOutageAsync()
    {
        using var browser = new LiveBrowser(e); await browser.LoginAsync(e.Primary, e.Primary.Scenario);
        using var before = await browser.CrmAsync(HttpMethod.Get, "/api/site/" + e.Primary.Slug + "/forms/inquiry");
        var beforeCode = await ProblemCodeAsync(before);
        await ExecuteAsync(e.CrmConnection, "EXEC sys.sp_rename N'crm_identity.Projection', N'ProjectionUnavailable'");
        try
        {
            await WorkspaceAsync(browser, 503);
            using var published = await browser.CrmAsync(HttpMethod.Get, "/api/site/" + e.Primary.Slug + "/forms/inquiry");
            Require(published.StatusCode == before.StatusCode && await ProblemCodeAsync(published) == beforeCode, "C02_PUBLIC_ROUTE_CHANGED_WITH_PROJECTION_OUTAGE");
        }
        finally { await ExecuteAsync(e.CrmConnection, "EXEC sys.sp_rename N'crm_identity.ProjectionUnavailable', N'Projection'"); }
        await WorkspaceAsync(browser, 200);
        await ExecuteAsync(e.CrmConnection, "DELETE FROM crm_identity.Projection WHERE TenantId=@tenant AND AggregateId=N'permission:role:2'", ("tenant", e.Primary.Id));
        await WorkspaceAsync(browser, 503);
        await e.ForceReconciliationAsync(e.Primary.Id); await WorkspaceAsync(browser, 200);
    }
    private async Task SourceOutageAsync()
    {
        using var browser = new LiveBrowser(e); await browser.LoginAsync(e.Primary, e.Primary.Scenario);
        await e.Core.StopAsync();
        try
        {
            await ExecuteAsync(e.CrmConnection, "UPDATE crm_identity.Reconciliation SET NextAttemptAtUtc=SYSUTCDATETIME() WHERE TenantId=@tenant", ("tenant", e.Primary.Id));
            await UntilAsync(async () => await ScalarAsync<int>(e.CrmConnection, "SELECT FailureCount FROM crm_identity.Reconciliation WHERE TenantId=@tenant", ("tenant", e.Primary.Id)) > 0,
                TimeSpan.FromSeconds(20), "C02_SOURCE_FAILURE_NOT_RECORDED");
            await WorkspaceAsync(browser, 503);
        }
        finally { e.StartCore(); await e.WaitHttpAsync(e.Core, e.Fixture.CoreOrigin + "/.well-known/openid-configuration"); }
        await e.ForceReconciliationAsync(e.Primary.Id); await WorkspaceAsync(browser, 200);
    }
    private async Task SenderCrashAsync()
    {
        using var admin = await AdministratorAsync();
        using var target = new LiveBrowser(e); await target.LoginAsync(e.Primary, e.Primary.Scenario);
        using var other = new LiveBrowser(e); await other.LoginAsync(e.Other, e.Other.Scenario);
        await e.WaitQueuesAsync(); await e.Dispatcher.StopAsync();
        foreach (var user in e.Primary.Users.Where(u => u.Label.StartsWith("sample-", StringComparison.Ordinal)).Take(96))
            await UpdateUserAsync(admin, user, true, e.Primary.Scenario.Id);
        var backlog = await ScalarAsync<int>(e.Fixture.Connection, "SELECT COUNT(*) FROM crm_identity.Cp6_OutboxMessage WHERE Status=0");
        Require(backlog >= 96, "C02_REAL_ORDINARY_BACKLOG_MISSING");
        await UpdateUserAsync(admin, e.Primary.Scenario, false);
        var priority = await e.LatestMessageAsync(e.Primary.Id, "user:" + e.Primary.Scenario.Id);
        Require(priority.PublishedAtUtc is null, "C02_CRASH_BOUNDARY_ALREADY_PUBLISHED");
        await e.Core.StopAsync();
        Require(await ScalarAsync<bool>(e.Fixture.Connection, "SELECT Enable FROM dbo.Sys_Users WHERE Id=@id", ("id", e.Primary.Scenario.Id)) == false, "C02_COMMIT_DID_NOT_SURVIVE_CORE_CRASH");
        e.StartCore(); await e.WaitHttpAsync(e.Core, e.Fixture.CoreOrigin + "/.well-known/openid-configuration");
        e.StartDispatcher(); await e.WaitInboxAsync(priority);
        await UntilAsync(async () => (await e.LatestMessageAsync(e.Primary.Id, priority.AggregateId)).PublishedAtUtc is not null, TimeSpan.FromSeconds(15), "C02_PRIORITY_NOT_PUBLISHED");
        priority = await e.LatestMessageAsync(e.Primary.Id, priority.AggregateId);
        var remaining = await ScalarAsync<int>(e.Fixture.Connection,
            "SELECT COUNT(*) FROM crm_identity.Cp6_OutboxMessage WHERE CreatedAtUtc<=@created AND (PublishedAtUtc IS NULL OR PublishedAtUtc>@published)",
            ("created", priority.CreatedAtUtc), ("published", priority.PublishedAtUtc));
        Require(remaining > 0, "C02_PRIORITY_DID_NOT_PROGRESS_BEFORE_BACKLOG");
        Require(await ScalarAsync<int>(e.CrmConnection, "SELECT COUNT(*) FROM crm_auth.AuthStates WHERE Kind='session' AND KeyHash=@hash", ("hash", target.SessionHash)) == 0, "C02_INBOX_DID_NOT_DELETE_SESSION");
        await WorkspaceAsync(target, 401); await WorkspaceAsync(other, 200);
        evidence.Observe("priority-backlog", new { actualBusinessEventsPending = backlog, ordinaryEventsNotYetPublishedAtPriorityPublication = remaining,
            coreProcessKilledAfterBusinessCommit = true, priorityPublishedAtUtc = priority.PublishedAtUtc });
        await UpdateUserAsync(admin, e.Primary.Scenario, true); await e.WaitInboxAsync(await e.LatestMessageAsync(e.Primary.Id, priority.AggregateId));
        await e.WaitQueuesAsync();
    }
    private async Task ReceiverCrashAsync()
    {
        using var admin = await AdministratorAsync();
        await e.WaitQueuesAsync(); await e.Dispatcher.StopAsync();
        await CommandAsync(admin, HttpMethod.Put, "/api/pub/dept/" + e.Primary.RootDepartmentId + "/leader", new { leaderId = e.Primary.Scenario.Id });
        var message = await e.LatestMessageAsync(e.Primary.Id, "department:" + e.Primary.RootDepartmentId);
        var committed = e.Relay.ArmAckLoss(message.MessageId); e.StartDispatcher();
        await committed.WaitAsync(TimeSpan.FromSeconds(30));
        await e.Crm.StopAsync(); e.Relay.ReleaseLostAck();
        Require(await ScalarAsync<int>(e.CrmConnection, "SELECT COUNT(*) FROM crm_identity.Cp6_InboxMessage WHERE MessageId=@id AND Status=1", ("id", message.MessageId)) == 1,
            "C02_RECEIVER_COMMIT_MISSING_AT_CRASH");
        e.StartCrm(); await e.WaitHttpAsync(e.Crm, e.Fixture.CrmOrigin + "/health/live");
        await UntilAsync(() => Task.FromResult(e.Relay.SuccessCount(message.MessageId) >= 2), TimeSpan.FromSeconds(30), "C02_BROKER_DID_NOT_REDELIVER_AFTER_ACK_LOSS");
        await e.WaitInboxAsync(message);
        Require(await ScalarAsync<int>(e.CrmConnection, "SELECT COUNT(*) FROM crm_identity.Cp6_InboxMessage WHERE MessageId=@id", ("id", message.MessageId)) == 1, "C02_CRASH_REPLAY_DUPLICATED_INBOX");
        evidence.Observe("receiver-crash", new { actualCrmProcessKilled = true, sqlCommittedBeforeLostResponse = true, successfulCallbacks = e.Relay.SuccessCount(message.MessageId), inboxRows = 1 });
    }
    private async Task ServiceRevocationAsync()
    {
        using var http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false, UseCookies = false });
        using var issue = ServiceRequest("/connect/token", e.Primary, new() { ["grant_type"] = "client_credentials", ["scope"] = "cp6.services" });
        using var issued = await http.SendAsync(issue); Require(issued.StatusCode == HttpStatusCode.OK, "C02_REAL_SERVICE_ISSUE_FAILED");
        using var json = JsonDocument.Parse(await issued.Content.ReadAsStringAsync());
        var raw = json.RootElement.GetProperty("access_token").GetString()!;
        var jwt = new JwtSecurityTokenHandler().ReadJwtToken(raw); var jti = jwt.Id;
        using (var read = new HttpRequestMessage(HttpMethod.Get, e.Fixture.CoreOrigin + "/internal/crm/identity/versions"))
        { read.Headers.Authorization = new("Bearer", raw); using var response = await http.SendAsync(read); Require(response.StatusCode == HttpStatusCode.OK, "C02_REAL_SERVICE_READER_FAILED"); }
        using (var anonymous = new HttpRequestMessage(HttpMethod.Post, e.Fixture.CoreOrigin + "/connect/service-revocations")
        { Content = new FormUrlEncodedContent(new Dictionary<string, string> { ["jti"] = jti }) })
        {
            using var response = await http.SendAsync(anonymous);
            Require(response.StatusCode == HttpStatusCode.Unauthorized, "C02_UNAUTHENTICATED_SERVICE_REVOCATION_NOT_REJECTED");
        }
        for (var i = 0; i < 2; i++)
        {
            using var revoke = ServiceRequest("/connect/service-revocations", e.Primary, new() { ["jti"] = jti });
            using var response = await http.SendAsync(revoke);
            if (response.StatusCode != HttpStatusCode.OK)
                await File.WriteAllTextAsync(Path.Combine(e.Manifest.PrivateRoot, "service-revoke-failure.json"),
                    JsonSerializer.Serialize(new { status = (int)response.StatusCode, body = await response.Content.ReadAsStringAsync() }, LiveJson.Options));
            Require(response.StatusCode == HttpStatusCode.OK, "C02_REAL_SERVICE_REVOKE_FAILED");
        }
        var message = await e.LatestMessageAsync(e.Primary.Id, IdentityEventContracts.TokenAggregate(e.Fixture.CoreOrigin, jti)); await e.WaitInboxAsync(message);
        using (var read = new HttpRequestMessage(HttpMethod.Get, e.Fixture.CoreOrigin + "/internal/crm/identity/versions"))
        { read.Headers.Authorization = new("Bearer", raw); using var response = await http.SendAsync(read);
            Require(response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden, "C02_REVOKED_SERVICE_TOKEN_ACCEPTED");
            evidence.Observe("service-token-revocation", new { deniedStatus = (int)response.StatusCode, actualSignedToken = true, durableRevocation = true }); }
        Require(await ScalarAsync<int>(e.CrmConnection, "SELECT COUNT(*) FROM crm_identity.RevokedToken WHERE Issuer=@issuer AND Jti=@jti AND SubjectId=@subject AND RetainUntilUtc>=DATEADD(second,60,ExpiresAtUtc)",
            ("issuer", e.Fixture.CoreOrigin), ("jti", jti), ("subject", "service:" + e.Primary.ReaderClientId)) == 1, "C02_SERVICE_REVOCATION_RETENTION_DIFFERS");
    }
    private async Task TimedAsync(string category)
    {
        using var admin = await AdministratorAsync();
        using var platform = new LiveBrowser(e); await platform.NativeLoginAsync(e.Fixture.Platform);
        var users = e.Primary.Users.Where(u => u.Label.StartsWith("sample-", StringComparison.Ordinal)).ToArray();
        for (var index = 0; index < users.Length; index++)
        {
            // The measured operation starts with an established healthy session. Finish
            // prior samples' distinct token/user callbacks before setting up that session.
            // No retry or drain is inserted after the measured business trigger.
            await e.WaitDeliveredAsync();
            await e.WaitHealthyAsync();
            var user = users[index]; using var browser = new LiveBrowser(e); await browser.LoginAsync(e.Primary, user);
            await WorkspaceAsync(browser, 200);
            var metadata = await SessionMetadataAsync(browser); var hash = browser.SessionHash; var jti = (string)metadata["Jti"];
            var started = DateTimeOffset.UtcNow; var business = started;
            DateTimeOffset? published = null, processed = null, deleted = null, denied = null; int? status = null;
            try
            {
                if (category == "user-disable") await UpdateUserAsync(admin, user, false, e.Primary.Scenario.Id);
                else if (category == "tenant-disable") await CommandAsync(platform, HttpMethod.Post, "/api/platform/tenant/" + e.Primary.Id + "/suspend");
                else await CommandAsync(browser, HttpMethod.Post, "/api/auth/logout");
                business = DateTimeOffset.UtcNow;
                var aggregate = category == "user-disable" ? "user:" + user.Id : category == "tenant-disable" ? "tenant:" + e.Primary.Id
                    : IdentityEventContracts.TokenAggregate(e.Fixture.CoreOrigin, jti);
                var message = await e.LatestMessageAsync(e.Primary.Id, aggregate);
                processed = await e.WaitInboxAsync(message);
                // Observe durable deletion before the first post-trigger management request, so an
                // upstream rejection cannot be mistaken for event-driven session invalidation.
                await UntilAsync(async () => await ScalarAsync<int>(e.CrmConnection,
                    "SELECT COUNT(*) FROM crm_auth.AuthStates WHERE Kind='session' AND KeyHash=@hash", ("hash", hash)) == 0, TimeSpan.FromSeconds(30), "C02_EVENT_SESSION_DELETE_TIMEOUT");
                deleted = DateTimeOffset.UtcNow;
                await UntilAsync(async () => (await e.LatestMessageAsync(e.Primary.Id, aggregate)).PublishedAtUtc is not null, TimeSpan.FromSeconds(15), "C02_PUBLISH_TIMESTAMP_MISSING");
                published = (await e.LatestMessageAsync(e.Primary.Id, aggregate)).PublishedAtUtc;
                using var response = await browser.CrmAsync(HttpMethod.Get, "/api/crm/v1/workspace");
                denied = DateTimeOffset.UtcNow; status = (int)response.StatusCode;
                Require(status is 401 or 403 && !(await response.Content.ReadAsStringAsync()).Contains("C02 sample-", StringComparison.Ordinal), "C02_MANAGEMENT_NOT_DENIED_AFTER_EVENT");
                var elapsed = (denied.Value - started).TotalMilliseconds;
                evidence.AddSample(new(category, index + 1, started, business, published, processed, deleted, denied, status,
                    elapsed <= 30000, elapsed, elapsed <= 30000 ? null : "C02_DENIAL_OVER_30_SECONDS"));
                Require(elapsed <= 30000, "C02_DENIAL_OVER_30_SECONDS");
            }
            catch (Exception error)
            {
                if (denied is null) evidence.AddSample(new(category, index + 1, started, business, published, processed, deleted, denied, status,
                    false, (DateTimeOffset.UtcNow - started).TotalMilliseconds, error is TimeoutException ? "C02_TRANSPORT_TIMEOUT" : "C02_TIMING_SCENARIO_FAILED"));
                throw;
            }
            if (category == "user-disable")
            { await UpdateUserAsync(admin, user, true, e.Primary.Scenario.Id); await e.WaitInboxAsync(await e.LatestMessageAsync(e.Primary.Id, "user:" + user.Id)); }
            else if (category == "tenant-disable")
            {
                await CommandAsync(platform, HttpMethod.Post, "/api/platform/tenant/" + e.Primary.Id + "/reactivate");
                await e.WaitInboxAsync(await e.LatestMessageAsync(e.Primary.Id, "tenant:" + e.Primary.Id));
            }
            if ((index + 1) % 10 == 0) Console.WriteLine($"TIMING {category}: {index + 1}/{users.Length} actual samples completed");
        }
        Require(users.Length == e.Fixture.SamplesPerCategory, "C02_SAMPLE_COUNT_DIFFERS");
        evidence.Observe(category + "-preconditions", new { priorMessagesProcessedBeforeEachLogin = true, successfulMeasuredSessions = users.Length });
    }
    private async Task<LiveBrowser> AdministratorAsync()
    { var browser = new LiveBrowser(e); try { await browser.NativeLoginAsync(e.Primary.Administrator); return browser; } catch { browser.Dispose(); throw; } }
    private async Task SetPermissionsAsync(LiveBrowser admin, bool enabled) => await CommandAsync(admin, HttpMethod.Put, "/api/pub/role-perm/2",
        new { menuIds = enabled ? new[] { 9901 } : [], actions = enabled ? new[] { "query", "add", "edit", "view-pii" }.Select(action => new { menuId = 9901, actionCode = action }).ToArray() : [] });
    private async Task SetScopeAsync(LiveBrowser admin, int scope) => await CommandAsync(admin, HttpMethod.Put, "/api/pub/role-perm/data-scope/2",
        new[] { new { resourceKey = "crm-lead", scopeType = scope, customDeptIds = Array.Empty<Guid>() } });
    private static Task UpdateUserAsync(LiveBrowser admin, LiveUser user, bool enabled, Guid? manager = null) => CommandAsync(admin, HttpMethod.Put, "/api/user",
        new { id = user.Id, userName = user.UserName, nickName = "C02 " + user.Label, roleId = user.RoleId, enable = enabled, deptId = user.DepartmentId, managerId = manager, password = "" });
    private static async Task CommandAsync(LiveBrowser browser, HttpMethod method, string path, object? body = null)
    {
        using var response = await browser.CoreAsync(method, path, body);
        Require(response.IsSuccessStatusCode, "C02_ACTUAL_BUSINESS_COMMAND_FAILED_" + (int)response.StatusCode);
    }
    private async Task<Dictionary<string, object>> SessionMetadataAsync(LiveBrowser browser) => (await RowsAsync(e.CrmConnection,
        "SELECT TenantId,SubjectId,Issuer,Jti,AuthenticationEpoch FROM crm_auth.AuthStates WHERE Kind='session' AND KeyHash=@hash", ("hash", browser.SessionHash))).Single();
    private static async Task WorkspaceAsync(LiveBrowser browser, params int[] expected)
    {
        using var response = await browser.CrmAsync(HttpMethod.Get, "/api/crm/v1/workspace");
        Require(expected.Contains((int)response.StatusCode), "C02_MANAGEMENT_STATUS_" + (int)response.StatusCode);
        if (!response.IsSuccessStatusCode) Require(!(await response.Content.ReadAsStringAsync()).Contains("C02 scenario", StringComparison.Ordinal), "C02_DENIAL_EXPOSED_DIRECTORY_DATA");
    }
    private static async Task<string?> ProblemCodeAsync(HttpResponseMessage response)
    { using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync()); return json.RootElement.TryGetProperty("code", out var code) ? code.GetString() : null; }
    private HttpRequestMessage ServiceRequest(string path, LiveTenant tenant, Dictionary<string, string> form)
    {
        var request = new HttpRequestMessage(HttpMethod.Post, e.Fixture.CoreOrigin + path) { Content = new FormUrlEncodedContent(form) };
        request.Headers.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes(
            Uri.EscapeDataString(tenant.ReaderClientId) + ":" + Uri.EscapeDataString(tenant.ReaderSecret))));
        return request;
    }
}
