[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$CoreRoot,
    [Parameter(Mandatory)][string]$CrmRoot,
    [Parameter(Mandatory)][string]$PublishRoot,
    [Parameter(Mandatory)][string]$NodeCommand,
    [switch]$KeepRunning,
    [Parameter(Mandatory)][string]$CertificateConfig,
    [Parameter(Mandatory)][string]$PrivateParent,
    [Parameter(Mandatory)][string]$EvidencePath,
    [string]$Scope = 'actual-browser-session-and-management,business-role-membership-permission-removal-and-department-move',
    [string]$DotnetCommand = 'dotnet'
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = (Resolve-Path -LiteralPath $CrmRoot).Path
$publication = (Resolve-Path -LiteralPath $PublishRoot).Path
$core = (Resolve-Path -LiteralPath $CoreRoot).Path
$publicRoot = [IO.Path]::GetFullPath($EvidencePath)
if (Test-Path -LiteralPath (Join-Path $publicRoot 'summary.json')) { throw 'Use a fresh attempt directory; previous results must be preserved.' }
[void][IO.Directory]::CreateDirectory($publicRoot)
$privateRoot = $null
$stage = 'preflight'
$exitCode = 1
$owned = $false
$cleanupOk = $true
$project = 'cp6-c02-live-' + [guid]::NewGuid().ToString('N').Substring(0, 12)
$compose = Join-Path $core 'eng/crm/identity-events-fixture/transport/compose.yaml'
$helper = Join-Path $core 'eng/crm/identity-events-fixture/bin/Debug/net8.0/CP6.IdentityEvents.Fixture.dll'
$runner = Join-Path $PSScriptRoot 'bin/Release/net8.0/PublishedSmoke.dll'
$coreApi = Join-Path $publication 'core-api/CP6.WebApi.dll'
$crmApi = Join-Path $publication 'crm-api/CP6.CRM.Api.dll'
$names = @('CP6_C02_PROBE_APP_PORT', 'CP6_C02_PROBE_HTTP_PORT', 'CP6_C02_PROBE_GRPC_PORT', 'APP_API_TOKEN')
$saved = @{}
foreach ($name in $names) { $saved[$name] = [Environment]::GetEnvironmentVariable($name, 'Process') }
function Write-Json([string]$Path, $Value) {
    [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 40), [Text.UTF8Encoding]::new($false))
}
function Source-Sha([string]$Path) {
    $sha = & git -C $Path rev-parse HEAD
    if ($LASTEXITCODE -ne 0 -or $sha -cnotmatch '^[0-9a-f]{40}$') { throw 'Exact source commit is required.' }
    $changes = & git -C $Path status --porcelain
    if ($LASTEXITCODE -ne 0 -or $changes) { throw 'Commit reviewed source locally before live acceptance. No push is required.' }
    return $sha.Trim()
}
try {
    if (-not $IsWindows -or [string]::IsNullOrWhiteSpace($env:CP6_C02_TEST_SQL)) { throw 'Windows and an explicit isolated local SQL input are required.' }
    foreach ($binary in @($helper, $runner, $coreApi, $crmApi)) {
        if (-not (Test-Path -LiteralPath $binary)) { throw 'Build the affected fixture and acceptance projects locally before this run.' }
    }
    $coreSha = Source-Sha $core
    $crmSha = Source-Sha $root
    $certificateConfigPath = (Resolve-Path -LiteralPath $CertificateConfig).Path
    $certificateSettings = Get-Content -LiteralPath $certificateConfigPath -Raw | ConvertFrom-Json
    $certificatePath = [IO.Path]::GetFullPath([string]$certificateSettings.path, (Split-Path $certificateConfigPath))
    $certificate = [Security.Cryptography.X509Certificates.X509Certificate2]::new($certificatePath,
        [string]$certificateSettings.password, [Security.Cryptography.X509Certificates.X509KeyStorageFlags]::EphemeralKeySet)
    $chain = [Security.Cryptography.X509Certificates.X509Chain]::new()
    try {
        $chain.ChainPolicy.RevocationMode = 'NoCheck'
        $chain.ChainPolicy.DisableCertificateDownloads = $true
        [void]$chain.ChainPolicy.ApplicationPolicy.Add([Security.Cryptography.Oid]::new('1.3.6.1.5.5.7.3.1'))
        if (-not $certificate.HasPrivateKey -or -not $certificate.MatchesHostname('localhost', $true, $false) -or
            $certificate.NotAfter.ToUniversalTime() -le [DateTime]::UtcNow.AddDays(1) -or -not $chain.Build($certificate)) {
            throw 'An existing trusted localhost TLS certificate is required.'
        }
    } finally { $chain.Dispose(); $certificate.Dispose() }
    $parent = [IO.Path]::GetFullPath($PrivateParent)
    if ([IO.DriveInfo]::new([IO.Path]::GetPathRoot($parent)).DriveFormat -ne 'NTFS') { throw 'Private output requires NTFS.' }
    $ancestor = $parent
    while ($ancestor) {
        if (Test-Path -LiteralPath $ancestor) {
            if ((Test-Path -LiteralPath (Join-Path $ancestor '.git')) -or
                ((Get-Item -LiteralPath $ancestor).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Private output must be outside Git and filesystem links.' }
        }
        $next = [IO.Directory]::GetParent($ancestor)
        $ancestor = if ($next) { $next.FullName } else { $null }
    }
    $privateRoot = Join-Path $parent ('c02-' + [guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($privateRoot)
    $acl = [Security.AccessControl.DirectorySecurity]::new()
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sid in @([Security.Principal.WindowsIdentity]::GetCurrent().User, [Security.Principal.SecurityIdentifier]::new('S-1-5-18'))) {
        $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($sid, 'FullControl',
            [Security.AccessControl.InheritanceFlags]'ContainerInherit, ObjectInherit', 'None', 'Allow'))
    }
    Set-Acl -LiteralPath $privateRoot -AclObject $acl
    $ports = @(); $reservations = @()
    try {
        1..8 | ForEach-Object {
            $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, 0)
            $listener.Start(); $reservations += $listener; $ports += $listener.LocalEndpoint.Port
        }
    } finally { foreach ($listener in $reservations) { $listener.Stop() } }
    $env:CP6_C02_PROBE_APP_PORT = [string]$ports[0]
    $env:CP6_C02_PROBE_HTTP_PORT = [string]$ports[1]
    $env:CP6_C02_PROBE_GRPC_PORT = [string]$ports[2]
    $sidecarValue = [Convert]::ToBase64String([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
    $env:APP_API_TOKEN = $sidecarValue
    $images = @()
    foreach ($image in @('apache/kafka:4.3.1', 'daprio/daprd:1.18.2')) {
        $identity = & docker image inspect $image --format '{{.Id}}'
        if ($LASTEXITCODE -ne 0) { throw 'Required cached transport image is missing. This script never builds or pulls images.' }
        $images += @{ image = $image; imageId = $identity.Trim() }
    }
    Write-Json (Join-Path $publicRoot 'environment.json') @{ project = $project; images = $images; coreSourceSha = $coreSha; crmSourceSha = $crmSha;
        coreApiAssemblySha256 = (Get-FileHash $coreApi).Hash.ToLowerInvariant();
        crmApiAssemblySha256 = (Get-FileHash $crmApi).Hash.ToLowerInvariant();
        publicationKind = 'Release APIs and production web, actual local smoke only';
        fixtureAssemblySha256 = (Get-FileHash $helper).Hash.ToLowerInvariant(); runnerAssemblySha256 = (Get-FileHash $runner).Hash.ToLowerInvariant() }
    $settings = @{ coreOrigin = 'https://localhost:' + $ports[3]; crmOrigin = 'https://localhost:' + $ports[4];
        daprHttpEndpoint = 'http://127.0.0.1:' + $ports[1]; daprGrpcEndpoint = 'http://127.0.0.1:' + $ports[2];
        certificatePath = $certificatePath; certificatePassword = [string]$certificateSettings.password; samplesPerCategory = 100 }
    $stage = 'core-fixture-initialize'
    $settingsPath = Join-Path $privateRoot 'settings.json'
    Write-Json $settingsPath $settings
    & $DotnetCommand $helper 'live-initialize' $settingsPath $privateRoot *> (Join-Path $privateRoot 'core-initialize.log')
    if ($LASTEXITCODE -ne 0) { throw 'Core real SQL initialization failed; private diagnostics retained.' }
    $fixtures = @(Get-ChildItem -LiteralPath $privateRoot -Directory | Where-Object { $_.Name -cmatch '^CP6C02Live_[a-f0-9]{32}$' })
    if ($fixtures.Count -ne 1) { throw 'Exactly one owned Core fixture must exist.' }
    $manifestPath = Join-Path $privateRoot 'run.json'
    Write-Json $manifestPath @{ privateRoot = $privateRoot; publicRoot = $publicRoot; coreRoot = $core; crmRoot = $root;
        coreSourceSha = $coreSha; crmSourceSha = $crmSha; fixturePath = Join-Path $fixtures[0].FullName 'live-fixture.json';
        certificatePath = $certificatePath; certificatePassword = [string]$certificateSettings.password;
        dotnetCommand = (Get-Command $DotnetCommand).Source; composeProject = $project; relayPort = $ports[0]; crmCallbackPort = $ports[5];
        daprHttpEndpoint = $settings.daprHttpEndpoint; daprGrpcEndpoint = $settings.daprGrpcEndpoint; appApiToken = $env:APP_API_TOKEN; scope = $Scope;
        coreApiAssembly = $coreApi; crmApiAssembly = $crmApi;
        coreApiOrigin = 'https://localhost:' + $ports[6]; crmApiOrigin = 'https://localhost:' + $ports[7];
        coreWebRoot = Join-Path $publication 'core-web'; crmWebRoot = Join-Path $publication 'crm-web';
        nodeCommand = (Get-Command $NodeCommand).Source; webServerPath = Join-Path $PSScriptRoot 'servers.cjs';
        keepRunning = [bool]$KeepRunning }
    $fixture = Get-Content -LiteralPath (Join-Path $fixtures[0].FullName 'live-fixture.json') -Raw | ConvertFrom-Json
    $previewUsers = foreach ($tenant in $fixture.tenants) {
        foreach ($user in $tenant.users | Where-Object { $_.label -in @('administrator','scenario') }) {
            @{ organization = $tenant.slug; role = $user.label; userName = $user.userName; password = $user.password }
        }
    }
    Write-Json (Join-Path $privateRoot 'preview-credentials.json') @{ coreOrigin = $settings.coreOrigin; crmOrigin = $settings.crmOrigin; users = @($previewUsers) }
    Write-Json (Join-Path $publicRoot 'preview-control.json') @{ privateRoot = $privateRoot; manifestPath = $manifestPath; stopFile = Join-Path $privateRoot 'stop-preview' }
    $stage = 'transport-startup'
    $owned = $true
    & docker compose -p $project -f $compose up -d --pull never --no-build *> (Join-Path $privateRoot 'compose-up.log')
    if ($LASTEXITCODE -ne 0) { throw 'Owned Dapr/Kafka startup failed.' }
    $stage = 'real-acceptance'
    & $DotnetCommand $runner $manifestPath 2>&1 | Tee-Object -FilePath (Join-Path $privateRoot 'acceptance-console.log')
    $exitCode = $LASTEXITCODE
} catch {
    if ($privateRoot) { [IO.File]::WriteAllText((Join-Path $privateRoot 'wrapper-failure.log'), $_.ToString()) }
    Write-Host "C02 local acceptance failed at $stage. Original diagnostics retained."
    $exitCode = 1
} finally {
    if ($privateRoot) {
        try {
            foreach ($file in Get-ChildItem -LiteralPath $privateRoot -Filter '*-process.json') {
                $record = Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json
                $process = Get-Process -Id $record.pid -ErrorAction SilentlyContinue
                if ($process -and $process.StartTime.ToUniversalTime().Ticks -eq $record.startUtcTicks) { $process.Kill($true); $process.WaitForExit() }
            }
            & $DotnetCommand $helper 'live-cleanup' $privateRoot *> (Join-Path $privateRoot 'database-cleanup.log')
            if ($LASTEXITCODE -ne 0) { throw 'Owned database cleanup failed.' }
        } catch { $cleanupOk = $false; [IO.File]::WriteAllText((Join-Path $privateRoot 'wrapper-cleanup-failure.log'), $_.ToString()) }
    }
    if ($owned) {
        & docker compose -p $project -f $compose logs --no-color *> (Join-Path $privateRoot 'transport.log')
        & docker compose -p $project -f $compose down --timeout 10 *> (Join-Path $privateRoot 'compose-cleanup.log')
        if ($LASTEXITCODE -ne 0) { $cleanupOk = $false }
        $remaining = @(& docker ps -aq --filter "label=com.docker.compose.project=$project")
        if ($LASTEXITCODE -ne 0 -or $remaining.Count -ne 0) { $cleanupOk = $false }
    }
    foreach ($name in $names) { [Environment]::SetEnvironmentVariable($name, $saved[$name], 'Process') }
    Write-Json (Join-Path $publicRoot 'cleanup.json') @{ passed = $cleanupOk; ownedComposeProject = $project; observedAtUtc = [DateTime]::UtcNow.ToString('o') }
    if (-not $cleanupOk) { $exitCode = 1 }
    $summaryPath = Join-Path $publicRoot 'summary.json'
    if (-not (Test-Path -LiteralPath $summaryPath)) {
        Write-Json $summaryPath @{ schemaId = 'cp6.crm.c02-real-transport.v1'; conclusion = 'failure'; scope = $Scope;
            total = 1; passed = 0; failed = 1; skipped = 0; cases = @(@{name = $stage; passed = $false}) }
        [IO.File]::WriteAllText((Join-Path $publicRoot 'junit.xml'), "<testsuite name=`"c02-real-transport`" tests=`"1`" failures=`"1`" skipped=`"0`"><testcase name=`"$stage`"><failure message=`"Fixture startup failed; original diagnostics retained.`" /></testcase></testsuite>")
    } elseif (-not $cleanupOk) {
        $summary = Get-Content -LiteralPath $summaryPath -Raw | ConvertFrom-Json -AsHashtable
        $summary.conclusion = 'failure'; $summary.cleanupPassed = $false
        Write-Json $summaryPath $summary
    }
}
Write-Host "C02 local real transport acceptance exited $exitCode; public evidence: $publicRoot"
exit $exitCode
