using System.Text.Json;
using CP6.CRM.C02Acceptance;

if (args.Length != 1) throw new ArgumentException("An explicit private live-run manifest is required.");
var manifest = JsonSerializer.Deserialize<RunManifest>(await File.ReadAllTextAsync(args[0]), LiveJson.Options)!;
var evidence = new LiveEvidence(manifest);
await using var environment = new LiveEnvironment(manifest, evidence);
try
{
    await evidence.CaseAsync("actual-core-crm-sql-service-snapshot-baseline", environment.InitializeAsync);
    var scenarios = new LiveScenarios(environment, evidence);
    await scenarios.RunAsync();
    evidence.Complete();
    evidence.Save();
    await File.WriteAllTextAsync(Path.Combine(manifest.PublicRoot, "ready.json"), JsonSerializer.Serialize(new
    { coreOrigin = environment.Fixture.CoreOrigin, crmOrigin = environment.Fixture.CrmOrigin,
        coreSourceSha = manifest.CoreSourceSha, crmSourceSha = manifest.CrmSourceSha, keepRunning = manifest.KeepRunning,
        observedAtUtc = DateTimeOffset.UtcNow }, LiveJson.Options));
    if (manifest.KeepRunning)
    {
        Console.WriteLine("Published preview ready; waiting for the private stop-preview file.");
        while (!File.Exists(Path.Combine(manifest.PrivateRoot, "stop-preview"))) await Task.Delay(1000);
    }
}
catch (Exception error)
{
    await File.WriteAllTextAsync(Path.Combine(manifest.PrivateRoot, "acceptance-failure.log"), error.ToString());
    try { await environment.RecordFailureDiagnosticsAsync(); }
    catch (Exception diagnosticError)
    { await File.WriteAllTextAsync(Path.Combine(manifest.PrivateRoot, "state-capture-failure.log"), diagnosticError.ToString()); }
    Environment.ExitCode = 1;
}
finally
{
    try { await environment.DisposeAsync(); }
    catch (Exception error)
    {
        evidence.Failure("owned-resources-cleanup");
        await File.WriteAllTextAsync(Path.Combine(manifest.PrivateRoot, "cleanup-failure.log"), error.ToString());
        Environment.ExitCode = 1;
    }
    evidence.Save();
}

namespace CP6.CRM.C02Acceptance
{
    internal static class LiveJson
    {
        public static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web) { WriteIndented = true };
    }
    internal sealed record RunManifest(string PrivateRoot, string PublicRoot, string CoreRoot, string CrmRoot,
        string CoreSourceSha, string CrmSourceSha, string FixturePath, string CertificatePath, string CertificatePassword,
        string DotnetCommand, string ComposeProject, int RelayPort, int CrmCallbackPort, string DaprHttpEndpoint,
        string DaprGrpcEndpoint, string AppApiToken, string CoreApiAssembly, string CrmApiAssembly,
        string CoreApiOrigin, string CrmApiOrigin, string CoreWebRoot, string CrmWebRoot,
        string NodeCommand, string WebServerPath, string Scope = "all", bool KeepRunning = false)
    {
        public string[] SelectedCases => Scope.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
        public bool Includes(string name) => Scope == "all" || SelectedCases.Contains(name, StringComparer.Ordinal);
    }
    internal sealed record CoreFixture(string Database, string Connection, string CoreContentRoot, string CoreOrigin,
        string CrmOrigin, string BrowserSecret, LiveTenant[] Tenants, LiveUser Platform, int SamplesPerCategory);
    internal sealed record LiveTenant(Guid Id, string Slug, string Region, Guid RootDepartmentId, Guid ChildDepartmentId,
        Guid TargetDepartmentId, string ReaderClientId, string ReaderSecret, LiveUser[] Users)
    {
        public LiveUser Administrator => Users.Single(u => u.Label == "administrator");
        public LiveUser Scenario => Users.Single(u => u.Label == "scenario");
    }
    internal sealed record LiveUser(Guid Id, string Label, string UserName, string Password, int RoleId, Guid? DepartmentId);
}
