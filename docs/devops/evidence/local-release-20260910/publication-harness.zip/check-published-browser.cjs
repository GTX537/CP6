const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');
const manifest = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const attempt = process.argv[3] || '1';
if (!/^[1-9][0-9]*$/.test(attempt)) throw Error('A numeric browser attempt is required.');
const resultPath = path.join(manifest.publicRoot, `browser-summary-attempt-${attempt}.json`);
if (fs.existsSync(resultPath)) throw Error('Use a fresh browser attempt; previous evidence is immutable.');
const access = JSON.parse(fs.readFileSync(path.join(manifest.privateRoot, 'preview-credentials.json'), 'utf8'));
const { chromium } = createRequire(path.join(manifest.crmRoot, 'package.json'))('playwright');
const { expect } = createRequire(path.join(manifest.crmRoot, 'package.json'))('@playwright/test');
const user = access.users.find(user => user.organization === 'c02-primary' && user.role === 'scenario');
const result = { schemaId: 'cp6.local-published-browser.v1', coreSourceSha: manifest.coreSourceSha, crmSourceSha: manifest.crmSourceSha,
  startedAtUtc: new Date().toISOString(), passed: false, assertions: [] };
let browser;
(async () => {
  browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ viewport: { width: 1360, height: 900 } });
  const page = await context.newPage();
  await page.goto(access.crmOrigin + '/crm/login');
  await page.getByLabel('组织代码').fill(user.organization);
  await page.getByRole('button', { name: '继续登录' }).click();
  await page.locator('input[autocomplete=username]').waitFor();
  await page.locator('.tenant-change').click();
  await page.locator('input[autocomplete=organization]').fill(user.organization);
  await page.locator('input[autocomplete=username]').fill(user.userName);
  await page.locator('input[autocomplete=current-password]').fill(user.password);
  await page.locator('button.login-button').click();
  await expect.poll(() => new URL(page.url()).origin === access.crmOrigin && new URL(page.url()).pathname === '/crm/leads', { timeout: 45000 }).toBe(true);
  await expect(page.getByRole('main')).toContainText('线索工作台');
  result.assertions.push('actual Vue password login and PKCE returned to production Next CRM');
  const status = await page.evaluate(async () => {
    const session = await fetch('/crm/session', { cache: 'no-store' });
    const workspace = await fetch('/api/crm/v1/workspace', { cache: 'no-store' });
    const value = await session.json();
    return { session: session.status, workspace: workspace.status, browserTokenExposed: 'accessToken' in value };
  });
  if (status.session !== 200 || status.workspace !== 200 || status.browserTokenExposed) throw Error('Published browser session/workspace verification failed.');
  result.assertions.push('actual browser session and authorized workspace both returned 200 without exposing an access token');
  const cookies = await context.cookies(access.crmOrigin);
  const session = cookies.find(cookie => cookie.name === '__Host-cp6-crm-session');
  if (!session?.httpOnly || !session.secure || session.sameSite !== 'Lax') throw Error('Published secure session cookie verification failed.');
  result.assertions.push('actual browser session cookie is Secure, HttpOnly and SameSite=Lax');
  await page.screenshot({ path: path.join(manifest.publicRoot, 'published-crm-browser.png'), fullPage: false });
  result.passed = true;
})().catch(error => {
  fs.writeFileSync(path.join(manifest.privateRoot, 'published-browser-failure.log'), error.stack || String(error));
  process.exitCode = 1;
}).finally(async () => {
  if (browser) await browser.close();
  result.finishedAtUtc = new Date().toISOString();
  fs.writeFileSync(resultPath, JSON.stringify(result, null, 2));
  console.log(result.passed ? 'Published browser verification passed.' : 'Published browser verification failed; private diagnostics retained.');
});
