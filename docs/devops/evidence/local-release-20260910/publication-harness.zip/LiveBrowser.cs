using System.Net;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using CP6.CRM.Api.Authentication;
using Microsoft.AspNetCore.WebUtilities;

namespace CP6.CRM.C02Acceptance;

internal sealed class LiveBrowser(LiveEnvironment environment) : IDisposable
{
    private readonly CookieContainer cookies = new();
    private readonly HttpClient http = new(new HttpClientHandler { AllowAutoRedirect = false, UseCookies = false }) { Timeout = TimeSpan.FromSeconds(15) };
    public string SessionCookie => Cookie(environment.Fixture.CrmOrigin, CrmCookies.Session);
    public string SessionHash => CrmAuthenticationService.Hash(SessionCookie);
    private string Cookie(string origin, string name) => cookies.GetCookies(new Uri(origin))[name]?.Value ?? "";
    public async Task NativeLoginAsync(LiveUser user)
    {
        using var response = await CoreAsync(HttpMethod.Post, "/api/auth/login", new { userName = user.UserName, password = user.Password });
        LiveEnvironment.Require(response.StatusCode == HttpStatusCode.OK && Cookie(environment.Fixture.CoreOrigin, "cp6_at").Length > 0, "C02_REAL_NATIVE_PASSWORD_LOGIN_FAILED");
    }
    public async Task LoginAsync(LiveTenant tenant, LiveUser user)
    {
        await NativeLoginAsync(user);
        using (var form = await CrmAsync(HttpMethod.Get, "/crm/login")) LiveEnvironment.Require(form.StatusCode == HttpStatusCode.OK, "C02_REAL_CRM_LOGIN_FORM_FAILED");
        var csrf = Cookie(environment.Fixture.CrmOrigin, CrmCookies.LoginForm);
        using var start = await CrmAsync(HttpMethod.Post, "/crm/auth/start", new FormUrlEncodedContent(new Dictionary<string, string>
        { ["organizationSlug"] = tenant.Slug, ["returnUrl"] = "/crm/leads", ["csrfToken"] = csrf }));
        LiveEnvironment.Require(start.StatusCode == HttpStatusCode.Redirect && start.Headers.Location is not null, "C02_REAL_CRM_BEGIN_FAILED");
        var next = start.Headers.Location!;
        for (var step = 0; step < 4; step++)
        {
            LiveEnvironment.Require(next.GetLeftPart(UriPartial.Authority) == environment.Fixture.CoreOrigin &&
                next.AbsolutePath is "/connect/authorize" or "/api/auth/crm-authorize", "C02_UNEXPECTED_OIDC_REDIRECT");
            using var response = await CoreAsync(HttpMethod.Get, next.PathAndQuery);
            LiveEnvironment.Require(response.StatusCode == HttpStatusCode.Redirect && response.Headers.Location is not null, "C02_REAL_CORE_AUTHORIZATION_FAILED");
            next = new Uri(next, response.Headers.Location!);
            if (next.GetLeftPart(UriPartial.Authority) != environment.Fixture.CrmOrigin) continue;
            var query = QueryHelpers.ParseQuery(next.Query);
            LiveEnvironment.Require(next.AbsolutePath == "/crm/auth/callback" && query["iss"] == environment.Fixture.CoreOrigin, "C02_REAL_CALLBACK_BINDING_FAILED");
            using var callback = await CrmAsync(HttpMethod.Get, next.PathAndQuery);
            if (callback.StatusCode != HttpStatusCode.Redirect)
            {
                var body = await callback.Content.ReadAsStringAsync();
                await File.WriteAllTextAsync(Path.Combine(environment.Manifest.PrivateRoot, "last-callback-error.json"), body);
            }
            LiveEnvironment.Require(callback.StatusCode == HttpStatusCode.Redirect && SessionCookie.Length == 43, "C02_REAL_CRM_CALLBACK_FAILED");
            return;
        }
        throw new InvalidOperationException("C02_REAL_CALLBACK_NOT_REACHED");
    }
    public async Task<HttpResponseMessage> CoreAsync(HttpMethod method, string path, object? body = null)
    {
        var response = await SendAsync(method, new Uri(environment.Fixture.CoreOrigin + path),
            body is null ? null : JsonContent.Create(body, options: LiveJson.Options), false);
        if ((int)response.StatusCode >= 400)
            await File.WriteAllTextAsync(Path.Combine(environment.Manifest.PrivateRoot, "last-core-http-failure.json"),
                JsonSerializer.Serialize(new { method = method.Method, path, status = (int)response.StatusCode, body = await response.Content.ReadAsStringAsync() }, LiveJson.Options));
        return response;
    }
    public Task<HttpResponseMessage> CrmAsync(HttpMethod method, string path, HttpContent? body = null) =>
        SendAsync(method, new Uri(environment.Fixture.CrmOrigin + path), body, true);
    private async Task<HttpResponseMessage> SendAsync(HttpMethod method, Uri uri, HttpContent? content, bool crm)
    {
        using var request = new HttpRequestMessage(method, uri) { Content = content };
        var cookie = cookies.GetCookieHeader(uri);
        if (cookie.Length > 0) request.Headers.Add("Cookie", cookie);
        if (method != HttpMethod.Get && method != HttpMethod.Head)
        {
            request.Headers.Add("Origin", crm ? environment.Fixture.CrmOrigin : environment.Fixture.CoreOrigin);
            if (!crm) request.Headers.Add("X-CSRF-Token", Cookie(environment.Fixture.CoreOrigin, "cp6_csrf"));
        }
        if (crm)
        {
            var bytes = content is null ? [] : await content.ReadAsByteArrayAsync();
            var time = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(System.Globalization.CultureInfo.InvariantCulture);
            var nonce = CrmAuthenticationService.RandomSecret(); var client = new string('a', 64);
            request.Headers.Add("X-CP6-BFF-Time", time); request.Headers.Add("X-CP6-BFF-Nonce", nonce); request.Headers.Add("X-CP6-BFF-Client", client);
            string Header(string name) => request.Headers.TryGetValues(name, out var values) ? string.Join(",", values)
                : content?.Headers.TryGetValues(name, out var contentValues) == true ? string.Join(",", contentValues) : "";
            var canonical = string.Join('\n', new[] { "CP6.CRM.BFF.v1", method.Method, uri.PathAndQuery,
                Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant(), time, nonce, client }
                .Concat(new[] { "origin", "cookie", "content-type", "x-csrf-token", "if-match", "idempotency-key" }.Select(Header)));
            request.Headers.Add("X-CP6-BFF-Signature", Convert.ToHexString(HMACSHA256.HashData(environment.ProxyKey, Encoding.UTF8.GetBytes(canonical))).ToLowerInvariant());
        }
        var response = await http.SendAsync(request);
        if (response.Headers.TryGetValues("Set-Cookie", out var returned))
            foreach (var value in returned) cookies.SetCookies(uri, value);
        return response;
    }
    public void Dispose() => http.Dispose();
}
