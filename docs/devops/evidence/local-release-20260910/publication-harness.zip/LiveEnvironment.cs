using System.Data;
using System.Net;
using System.Security.Cryptography;
using System.Text.Json;
using CP6.CRM.Api.Authentication;
using CP6.CRM.Infrastructure.Identity;
using CP6.CRM.Infrastructure.Identity.Contracts;
using CP6.CRM.Infrastructure.Persistence;
using CP6.Platform.Messaging;
using Dapr.Client;
using Microsoft.Data.SqlClient;

namespace CP6.CRM.C02Acceptance;

internal sealed class LiveEnvironment : IAsyncDisposable
{
    public RunManifest Manifest { get; }
    public CoreFixture Fixture { get; }
    public string CrmConnection { get; private set; } = "";
    public byte[] ProxyKey { get; } = RandomNumberGenerator.GetBytes(32);
    public OwnedProcess Core { get; }
    public OwnedProcess Crm { get; }
    public OwnedProcess Dispatcher { get; }
    public OwnedProcess Web { get; }
    public TransportRelay Relay { get; }
    public LiveTenant Primary => Fixture.Tenants[0];
    public LiveTenant Other => Fixture.Tenants[1];
    private readonly LiveEvidence evidence;
    private readonly List<string> ownedConnections = [];
    private readonly HttpClient http = new(new HttpClientHandler { AllowAutoRedirect = false, UseCookies = false }) { Timeout = TimeSpan.FromSeconds(10) };
    private readonly DaprClient dapr;
    private readonly HttpClient invocation;
    private readonly Cp6DaprTransport transport;
    private bool disposed;
    public LiveEnvironment(RunManifest manifest, LiveEvidence evidence)
    {
        Manifest = manifest; this.evidence = evidence;
        Fixture = JsonSerializer.Deserialize<CoreFixture>(File.ReadAllText(manifest.FixturePath), LiveJson.Options)!;
        Require(Fixture.SamplesPerCategory >= 100, "C02_REAL_ACCEPTANCE_REQUIRES_100_SAMPLES_PER_CATEGORY");
        Web = new(manifest, "web"); Core = new(manifest, "core"); Crm = new(manifest, "crm"); Dispatcher = new(manifest, "dispatcher"); Relay = new(manifest);
        dapr = new DaprClientBuilder().UseHttpEndpoint(manifest.DaprHttpEndpoint).UseGrpcEndpoint(manifest.DaprGrpcEndpoint).Build();
        invocation = new HttpClient { BaseAddress = new Uri(manifest.DaprHttpEndpoint), Timeout = TimeSpan.FromSeconds(15) };
        transport = new(dapr, invocation);
    }
    public async Task InitializeAsync()
    {
        CrmConnection = await CreateDatabaseAsync();
        var orgConnections = new Dictionary<Guid, string>();
        foreach (var tenant in Fixture.Tenants) orgConnections[tenant.Id] = await CreateDatabaseAsync();
        var auth = new CrmAuthOptions { Enabled = true, Issuer = Fixture.CoreOrigin, PublicOrigin = Fixture.CrmOrigin,
            ClientId = "CP6.Web", ClientSecret = Fixture.BrowserSecret, SessionConnectionString = CrmConnection,
            BffSharedSecretBase64 = Convert.ToBase64String(ProxyKey), DataProtectionKeyPath = Path.Combine(Manifest.PrivateRoot, "crm-keys") };
        var storage = new CrmStorageOptions { CatalogConnectionString = CrmConnection, HmacKeyBase64 = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32)),
            Organizations = Fixture.Tenants.Select(t => new CrmOrganizationRegistration { OrganizationId = t.Id, Region = t.Region,
                RouteKey = t.Slug, SiteKey = t.Slug, OrganizationSlug = t.Slug, OrganizationName = "C02 fixture", ConnectionString = orgConnections[t.Id] }).ToList() };
        var identity = new IdentityProjectionOptions { Enabled = true, DaprAppToken = Manifest.AppApiToken,
            Tenants = Fixture.Tenants.Select(t => new IdentityReaderRegistration { TenantId = t.Id, Region = t.Region, ClientId = t.ReaderClientId, ClientSecret = t.ReaderSecret }).ToList() };
        var crmRoot = Path.Combine(Manifest.PrivateRoot, "crm-content"); Directory.CreateDirectory(crmRoot);
        await File.WriteAllTextAsync(Path.Combine(crmRoot, "appsettings.json"), JsonSerializer.Serialize(new
        {
            CrmAuth = auth, CrmStorage = storage, CrmIdentity = identity,
            Kestrel = new { Certificates = new { Default = new { Path = Manifest.CertificatePath, Password = Manifest.CertificatePassword } } },
            Logging = new { LogLevel = new Dictionary<string, string> { ["Default"] = "Warning", ["Microsoft.AspNetCore"] = "Warning" } }
        }, LiveJson.Options));
        await using (var initialize = new OwnedProcess(Manifest, "crm-initialize"))
        {
            initialize.Start(crmRoot, CrmBinary, "--contentRoot", crmRoot, "--initialize-crm");
            Require(await initialize.WaitAsync(TimeSpan.FromMinutes(3)) == 0, "C02_REAL_CRM_INITIALIZATION_FAILED");
        }
        StartCore();
        await WaitHttpAsync(Core, Manifest.CoreApiOrigin + "/.well-known/openid-configuration");
        StartCrm();
        await WaitHttpAsync(Crm, Manifest.CrmApiOrigin + "/health/live");
        var webConfig = Path.Combine(Manifest.PrivateRoot, "web-settings.json");
        await File.WriteAllTextAsync(webConfig, JsonSerializer.Serialize(new
        {
            Manifest.CertificatePath, Manifest.CertificatePassword, Manifest.CoreApiOrigin, Manifest.CrmApiOrigin,
            Manifest.CoreWebRoot, Manifest.CrmWebRoot, Fixture.CoreOrigin, Fixture.CrmOrigin,
            bffKey = Convert.ToBase64String(ProxyKey)
        }, LiveJson.Options));
        Web.StartExecutable(Manifest.NodeCommand, Manifest.PrivateRoot, "--use-system-ca", Manifest.WebServerPath, webConfig);
        await WaitHttpAsync(Web, Fixture.CrmOrigin + "/crm/login");
        await WaitHttpAsync(Web, Fixture.CoreOrigin + "/login");
        await Relay.StartAsync();
        await UntilAsync(async () => await ScalarAsync<int>(CrmConnection,
            "SELECT COUNT(*) FROM crm_identity.Reconciliation WHERE Ready=1 AND FailureCount=0") == 2, TimeSpan.FromSeconds(120), "C02_REAL_BASELINE_IMPORT_TIMEOUT");
        StartDispatcher();
        await WaitDeliveredAsync();
        await WaitHealthyAsync();
        foreach (var tenant in Fixture.Tenants)
        {
            var expected = await RowsAsync(Fixture.Connection, "SELECT AggregateId,Version,PayloadSha256 FROM crm_identity.Snapshot WHERE TenantId=@tenant", ("tenant", tenant.Id));
            var actual = await RowsAsync(CrmConnection, "SELECT AggregateId,Version,PayloadSha256,NeedsReconciliation FROM crm_identity.Projection WHERE TenantId=@tenant", ("tenant", tenant.Id));
            Require(expected.Count == actual.Count && expected.All(e => actual.Any(a => Equals(e["AggregateId"], a["AggregateId"]) && Equals(e["Version"], a["Version"]) &&
                Equals(e["PayloadSha256"], a["PayloadSha256"]) && Equals(a["NeedsReconciliation"], false))), "C02_IMPORTED_BASELINE_DIFFERS");
        }
        evidence.Observe("baseline", new { tenants = 2, sourceSnapshots = await ScalarAsync<int>(Fixture.Connection, "SELECT COUNT(*) FROM crm_identity.Snapshot"),
            importedSnapshots = await ScalarAsync<int>(CrmConnection, "SELECT COUNT(*) FROM crm_identity.Projection"),
            realServiceTokenRecords = await ScalarAsync<int>(Fixture.Connection, "SELECT COUNT(*) FROM crm_identity.ServiceToken"),
            actualClock = true, signedReaderAuthentication = true, sourceOutboxDeliveredAndProjectionHealthy = true });
    }
    private string CrmBinary => Manifest.CrmApiAssembly;
    public void StartCore() => Core.Start(Fixture.CoreContentRoot,
        Manifest.CoreApiAssembly, "--contentRoot", Fixture.CoreContentRoot, "--urls", Manifest.CoreApiOrigin);
    public void StartCrm()
    {
        var root = Path.Combine(Manifest.PrivateRoot, "crm-content");
        Crm.Start(root, CrmBinary, "--contentRoot", root, "--urls", Manifest.CrmApiOrigin + ";http://127.0.0.1:" + Manifest.CrmCallbackPort);
    }
    public void StartDispatcher() => Dispatcher.Start(Fixture.CoreContentRoot,
        Path.Combine(Manifest.CoreRoot, "eng/crm/identity-events-fixture/bin/Debug/net8.0/CP6.IdentityEvents.Fixture.dll"),
        "live-dispatch", Path.Combine(Fixture.CoreContentRoot, "appsettings.Local.json"));
    public async Task WaitHttpAsync(OwnedProcess process, string uri) => await UntilAsync(async () =>
    {
        Require(process.Running, "C02_APPLICATION_EXITED_DURING_STARTUP");
        try { using var response = await http.GetAsync(uri); return response.IsSuccessStatusCode; }
        catch (Exception error) when (error is HttpRequestException or TaskCanceledException) { return false; }
    }, TimeSpan.FromSeconds(60), "C02_APPLICATION_START_TIMEOUT");
    public async Task WaitQueuesAsync() => await UntilAsync(async () =>
        await ScalarAsync<int>(Fixture.Connection, "SELECT (SELECT COUNT(*) FROM crm_identity.Cp6_OutboxMessage WHERE Status<>2)+(SELECT COUNT(*) FROM crm_identity_priority.Cp6_OutboxMessage WHERE Status<>2)") == 0,
        TimeSpan.FromSeconds(60), "C02_OUTBOX_DRAIN_TIMEOUT");
    public async Task WaitDeliveredAsync()
    {
        await UntilAsync(async () =>
        {
            var source = await RowsAsync(Fixture.Connection,
                "SELECT MessageId,Status FROM crm_identity.Cp6_OutboxMessage UNION ALL SELECT MessageId,Status FROM crm_identity_priority.Cp6_OutboxMessage");
            if (source.Any(row => Convert.ToInt32(row["Status"]) != 2)) return false;
            var completed = (await RowsAsync(CrmConnection, "SELECT MessageId FROM crm_identity.Cp6_InboxMessage WHERE Status=1"))
                .Select(row => (string)row["MessageId"]).ToHashSet(StringComparer.Ordinal);
            return source.All(row => completed.Contains((string)row["MessageId"]));
        }, TimeSpan.FromSeconds(45), "C02_PRECONDITION_DELIVERY_DRAIN_TIMEOUT");
    }

    public Task WaitHealthyAsync() => UntilAsync(async () =>
        await ScalarAsync<int>(CrmConnection, "SELECT COUNT(*) FROM crm_identity.Reconciliation WHERE Ready=1 AND FailureCount=0") == Fixture.Tenants.Length &&
        await ScalarAsync<int>(CrmConnection, "SELECT COUNT(*) FROM crm_identity.Projection WHERE NeedsReconciliation=1") == 0,
        TimeSpan.FromSeconds(45), "C02_PRECONDITION_VERIFIED_REPAIR_TIMEOUT");

    public Task WaitReconciliationSinceAsync(Guid tenant, DateTimeOffset since) => UntilAsync(async () =>
        await HasReconciliationSinceAsync(tenant, since), TimeSpan.FromSeconds(45), "C02_AUTOMATIC_RECONCILIATION_TIMEOUT");

    public async Task<bool> HasReconciliationSinceAsync(Guid tenant, DateTimeOffset since) =>
        await ScalarAsync<int>(CrmConnection,
            "SELECT COUNT(*) FROM crm_identity.Reconciliation WHERE TenantId=@tenant AND LastSuccessAtUtc>=@since AND FailureCount=0 AND Ready=1 " +
            "AND NOT EXISTS (SELECT 1 FROM crm_identity.Projection WHERE TenantId=@tenant AND NeedsReconciliation=1)",
            ("tenant", tenant), ("since", since)) == 1;

    public async Task RecordFailureDiagnosticsAsync()
    {
        if (CrmConnection.Length == 0) return;
        var snapshot = new
        {
            source = await RowsAsync(Fixture.Connection,
                "SELECT MessageId,AggregateId,Status,AggregateVersion FROM crm_identity.Cp6_OutboxMessage UNION ALL SELECT MessageId,AggregateId,Status,AggregateVersion FROM crm_identity_priority.Cp6_OutboxMessage"),
            inbox = await RowsAsync(CrmConnection, "SELECT MessageId,Status FROM crm_identity.Cp6_InboxMessage"),
            projections = await RowsAsync(CrmConnection, "SELECT TenantId,AggregateId,Version,NeedsReconciliation,DriftCode FROM crm_identity.Projection"),
            reconciliation = await RowsAsync(CrmConnection, "SELECT * FROM crm_identity.Reconciliation")
        };
        await File.WriteAllTextAsync(Path.Combine(Manifest.PrivateRoot, "failure-state.json"), JsonSerializer.Serialize(snapshot, LiveJson.Options));
    }
    public async Task<CoreMessage> LatestMessageAsync(Guid tenant, string aggregate, int? version = null)
    {
        var rows = await RowsAsync(Fixture.Connection, """
            SELECT TOP(1) * FROM (
              SELECT MessageId,TenantId,AggregateId,AggregateVersion,TopicName,PartitionKey,Payload,PayloadSha256,PublishedAtUtc,CreatedAtUtc FROM crm_identity.Cp6_OutboxMessage
              UNION ALL
              SELECT MessageId,TenantId,AggregateId,AggregateVersion,TopicName,PartitionKey,Payload,PayloadSha256,PublishedAtUtc,CreatedAtUtc FROM crm_identity_priority.Cp6_OutboxMessage
            ) q WHERE TenantId=@tenant AND AggregateId=@aggregate AND (@version IS NULL OR AggregateVersion=@version) ORDER BY AggregateVersion DESC
            """, ("tenant", tenant), ("aggregate", aggregate), ("version", version));
        Require(rows.Count == 1, "C02_ACTUAL_SOURCE_EVENT_MISSING"); var row = rows[0];
        return new((string)row["MessageId"], (Guid)row["TenantId"], (string)row["AggregateId"], (int)row["AggregateVersion"],
            (string)row["TopicName"], (string)row["PartitionKey"], (byte[])row["Payload"], (string)row["PayloadSha256"],
            row["PublishedAtUtc"] as DateTimeOffset?, (DateTimeOffset)row["CreatedAtUtc"]);
    }
    public async Task<DateTimeOffset> WaitInboxAsync(CoreMessage message, bool healthy = true)
    {
        DateTimeOffset processed = default;
        await UntilAsync(async () =>
        {
            var rows = await RowsAsync(CrmConnection, "SELECT ProcessedAtUtc,PayloadSha256 FROM crm_identity.Cp6_InboxMessage WHERE MessageId=@id AND Status=1", ("id", message.MessageId));
            if (rows.Count != 1) return false;
            Require((string)rows[0]["PayloadSha256"] == message.PayloadSha256, "C02_INBOX_BYTES_DIFFER_FROM_REAL_OUTBOX");
            processed = (DateTimeOffset)rows[0]["ProcessedAtUtc"];
            if (!healthy) return true;
            return await ScalarAsync<int>(CrmConnection, "SELECT COUNT(*) FROM crm_identity.Projection WHERE TenantId=@tenant AND AggregateId=@aggregate AND Version>=@version AND NeedsReconciliation=0",
                ("tenant", message.TenantId), ("aggregate", message.AggregateId), ("version", message.Version)) == 1;
        }, TimeSpan.FromSeconds(30), "C02_ACTUAL_INBOX_TIMEOUT");
        return processed;
    }
    public async Task PublishAsync(CoreMessage message, byte[]? payload = null, string? partition = null) =>
        await transport.PublishAsync("cp6-kafka-pubsub", message.Topic, payload ?? message.Payload, Cp6CloudEventCodec.StructuredContentType,
            new Dictionary<string, string> { ["partitionKey"] = partition ?? message.PartitionKey, ["rawPayload"] = "true" });
    public async Task ForceReconciliationAsync(Guid tenant)
    {
        var before = DateTimeOffset.UtcNow;
        await ExecuteAsync(CrmConnection, "UPDATE crm_identity.Reconciliation SET NextAttemptAtUtc=SYSUTCDATETIME() WHERE TenantId=@tenant", ("tenant", tenant));
        await UntilAsync(async () => await ScalarAsync<int>(CrmConnection,
            "SELECT COUNT(*) FROM crm_identity.Reconciliation WHERE TenantId=@tenant AND LastSuccessAtUtc>=@before AND FailureCount=0 AND Ready=1",
            ("tenant", tenant), ("before", before)) == 1, TimeSpan.FromSeconds(45), "C02_REAL_RECONCILIATION_RECOVERY_TIMEOUT");
    }
    private async Task<string> CreateDatabaseAsync()
    {
        var name = "CP6CrmC02Live_" + Guid.NewGuid().ToString("N");
        var sql = new SqlConnectionStringBuilder(Fixture.Connection) { InitialCatalog = "master", Pooling = false };
        var connection = new SqlConnectionStringBuilder(Fixture.Connection) { InitialCatalog = name }.ConnectionString;
        ownedConnections.Add(connection);
        await File.WriteAllTextAsync(Path.Combine(Manifest.PrivateRoot, "crm-owned-databases.json"), JsonSerializer.Serialize(ownedConnections.Select(c => new SqlConnectionStringBuilder(c).InitialCatalog), LiveJson.Options));
        await ExecuteAsync(sql.ConnectionString, $"CREATE DATABASE [{name}]");
        return connection;
    }
    public static async Task<List<Dictionary<string, object>>> RowsAsync(string connection, string statement, params (string Name, object? Value)[] values)
    {
        await using var db = new SqlConnection(connection); await db.OpenAsync();
        await using var command = db.CreateCommand(); command.CommandText = statement; command.CommandTimeout = 60;
        foreach (var (name, value) in values) command.Parameters.AddWithValue("@" + name, value ?? DBNull.Value);
        await using var reader = await command.ExecuteReaderAsync(); var rows = new List<Dictionary<string, object>>();
        while (await reader.ReadAsync())
        {
            var row = new Dictionary<string, object>(StringComparer.Ordinal);
            for (var i = 0; i < reader.FieldCount; i++) row[reader.GetName(i)] = reader.GetValue(i);
            rows.Add(row);
        }
        return rows;
    }
    public static async Task<T> ScalarAsync<T>(string connection, string statement, params (string Name, object? Value)[] values)
    {
        var rows = await RowsAsync(connection, statement, values);
        return (T)rows.Single().Values.Single();
    }
    public static async Task ExecuteAsync(string connection, string statement, params (string Name, object? Value)[] values)
    {
        await using var db = new SqlConnection(connection); await db.OpenAsync();
        await using var command = db.CreateCommand(); command.CommandText = statement; command.CommandTimeout = 60;
        foreach (var (name, value) in values) command.Parameters.AddWithValue("@" + name, value ?? DBNull.Value);
        await command.ExecuteNonQueryAsync();
    }
    public static async Task UntilAsync(Func<Task<bool>> predicate, TimeSpan timeout, string code)
    {
        var end = DateTimeOffset.UtcNow + timeout;
        do { if (await predicate()) return; await Task.Delay(100); } while (DateTimeOffset.UtcNow < end);
        throw new TimeoutException(code);
    }
    public static void Require(bool condition, string code) { if (!condition) throw new InvalidOperationException(code); }
    public async ValueTask DisposeAsync()
    {
        if (disposed) return; disposed = true;
        await Web.StopAsync(); await Dispatcher.StopAsync(); await Crm.StopAsync(); await Core.StopAsync(); await Relay.DisposeAsync();
        dapr.Dispose(); invocation.Dispose(); http.Dispose();
        foreach (var connection in ownedConnections)
        {
            var sql = new SqlConnectionStringBuilder(connection); var database = sql.InitialCatalog;
            Require(System.Text.RegularExpressions.Regex.IsMatch(database, "^CP6CrmC02Live_[a-f0-9]{32}$"), "C02_DATABASE_OWNERSHIP_INVALID");
            using (var pool = new SqlConnection(connection)) SqlConnection.ClearPool(pool);
            sql.InitialCatalog = "master"; sql.Pooling = false;
            try { await ExecuteAsync(sql.ConnectionString, $"IF DB_ID(N'{database}') IS NOT NULL BEGIN ALTER DATABASE [{database}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [{database}]; END"); }
            catch (SqlException ex) when (ex.Number == -2)
            { if (await ScalarAsync<int>(sql.ConnectionString, "SELECT COUNT(*) FROM sys.databases WHERE name=@name", ("name", database)) != 0) throw; }
        }
    }
}

internal sealed record CoreMessage(string MessageId, Guid TenantId, string AggregateId, int Version, string Topic,
    string PartitionKey, byte[] Payload, string PayloadSha256, DateTimeOffset? PublishedAtUtc, DateTimeOffset CreatedAtUtc);
