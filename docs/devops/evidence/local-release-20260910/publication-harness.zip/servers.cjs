const fs = require('node:fs');
const path = require('node:path');
const https = require('node:https');
const { createRequire } = require('node:module');

const config = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
for (const key of ['coreOrigin', 'crmOrigin', 'coreApiOrigin', 'crmApiOrigin']) {
  const url = new URL(config[key]);
  if (url.protocol !== 'https:' || url.hostname !== 'localhost' || !url.port || url.pathname !== '/') throw Error('Only explicit HTTPS localhost origins are accepted.');
}
process.env.NODE_ENV = 'production';
process.env.NEXT_TELEMETRY_DISABLED = '1';
process.env.CRM_API_ORIGIN = config.crmApiOrigin;
process.env.CRM_PUBLIC_ORIGIN = config.crmOrigin;
process.env.CRM_BFF_KEY_BASE64 = config.bffKey;
process.env.CRM_TRUSTED_CLIENT_IP_HEADER = 'x-cp6-local-client-ip';
const tls = { pfx: fs.readFileSync(config.certificatePath), passphrase: config.certificatePassword };
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.woff2': 'font/woff2' };
const coreRoot = path.resolve(config.coreWebRoot);
const coreServer = https.createServer(tls, (req, res) => {
  const url = new URL(req.url, config.coreOrigin);
  if (/^\/(api\/|connect\/|\.well-known\/|internal\/crm\/identity\/|health\/|healthz|hubs\/)/.test(url.pathname)) {
    const upstream = https.request(new URL(req.url, config.coreApiOrigin), { method: req.method, headers: { ...req.headers, host: new URL(config.coreOrigin).host } }, incoming => {
      res.writeHead(incoming.statusCode, incoming.headers); incoming.pipe(res);
    });
    upstream.on('error', () => { if (!res.headersSent) res.writeHead(502); res.end(); });
    req.pipe(upstream); return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); res.end(); return; }
  let pathname;
  try { pathname = decodeURIComponent(url.pathname); } catch { res.writeHead(400); res.end(); return; }
  let file = path.resolve(coreRoot, '.' + pathname);
  if (file !== coreRoot && !file.startsWith(coreRoot + path.sep)) { res.writeHead(400); res.end(); return; }
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) file = path.join(coreRoot, 'index.html');
  res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  if (req.method === 'HEAD') res.end(); else fs.createReadStream(file).pipe(res);
});
const next = createRequire(path.join(config.crmWebRoot, 'package.json'))('next');
const app = next({ dev: false, dir: config.crmWebRoot, hostname: 'localhost', port: Number(new URL(config.crmOrigin).port), webpack: true });
app.prepare().then(() => {
  const handle = app.getRequestHandler();
  https.createServer(tls, (req, res) => {
    req.headers['x-cp6-local-client-ip'] = req.socket.remoteAddress;
    handle(req, res).catch(() => { if (!res.headersSent) res.writeHead(500); res.end(); });
  }).listen(Number(new URL(config.crmOrigin).port), '127.0.0.1');
  coreServer.listen(Number(new URL(config.coreOrigin).port), '127.0.0.1');
  console.log('Published local Core and CRM web servers are ready.');
}).catch(() => { console.error('Published local web startup failed.'); process.exitCode = 1; });
