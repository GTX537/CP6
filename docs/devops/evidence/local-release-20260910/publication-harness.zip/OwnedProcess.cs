using System.Diagnostics;
using System.Text.Json;

namespace CP6.CRM.C02Acceptance;

internal sealed class OwnedProcess(RunManifest manifest, string name) : IAsyncDisposable
{
    private Process? process;
    private Task[] copies = [];
    private FileStream[] logs = [];
    private int generation;
    public bool Running => process is { HasExited: false };
    public void Start(string workingDirectory, params string[] arguments) => StartExecutable(manifest.DotnetCommand, workingDirectory, arguments);
    public void StartExecutable(string executable, string workingDirectory, params string[] arguments)
    {
        if (process is not null) throw new InvalidOperationException("Owned process must stop before restarting.");
        var start = new ProcessStartInfo(executable)
        { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true, WorkingDirectory = workingDirectory };
        foreach (var argument in arguments) start.ArgumentList.Add(argument);
        start.Environment["ASPNETCORE_ENVIRONMENT"] = "Development";
        process = Process.Start(start) ?? throw new InvalidOperationException("Owned process could not start.");
        File.WriteAllText(Path.Combine(manifest.PrivateRoot, name + "-process.json"), JsonSerializer.Serialize(new
        { pid = process.Id, startUtcTicks = process.StartTime.ToUniversalTime().Ticks }));
        generation++;
        logs = [File.Create(Path.Combine(manifest.PrivateRoot, $"{name}-{generation}.stdout.log")),
            File.Create(Path.Combine(manifest.PrivateRoot, $"{name}-{generation}.stderr.log"))];
        copies = [process.StandardOutput.BaseStream.CopyToAsync(logs[0]), process.StandardError.BaseStream.CopyToAsync(logs[1])];
    }
    public async Task<int> WaitAsync(TimeSpan timeout)
    {
        await process!.WaitForExitAsync().WaitAsync(timeout);
        return process.ExitCode;
    }
    public async Task StopAsync()
    {
        if (process is null) return;
        if (!process.HasExited) process.Kill(entireProcessTree: true);
        await process.WaitForExitAsync();
        await Task.WhenAll(copies);
        foreach (var log in logs) await log.DisposeAsync();
        process.Dispose(); process = null; copies = []; logs = [];
        File.Delete(Path.Combine(manifest.PrivateRoot, name + "-process.json"));
    }
    public ValueTask DisposeAsync() => new(StopAsync());
}
