using System.Security;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using CP6.CRM.Api.Authentication;
using CP6.CRM.Infrastructure.Identity;

namespace CP6.CRM.C02Acceptance;

internal sealed class LiveEvidence(RunManifest manifest)
{
    private readonly List<CaseResult> cases = [];
    private readonly List<LatencySample> samples = [];
    private readonly Dictionary<string, object> observations = [];
    private bool complete;
    public async Task CaseAsync(string name, Func<Task> action)
    {
        Console.WriteLine("CASE " + name);
        var started = DateTimeOffset.UtcNow;
        try { await action(); cases.Add(new(name, true, started, DateTimeOffset.UtcNow)); Console.WriteLine("PASS " + name); }
        catch { Failure(name, started); throw; }
        finally { Save(); }
    }
    public void Failure(string name, DateTimeOffset? started = null)
    {
        cases.Add(new(name, false, started ?? DateTimeOffset.UtcNow, DateTimeOffset.UtcNow));
        Console.WriteLine("FAIL " + name);
    }
    public void AddSample(LatencySample value) { samples.Add(value); Save(); }
    public void Observe(string name, object value) { observations[name] = value; Save(); }
    public void Complete()
    {
        var expected = manifest.Scope == "all" ? 13 : manifest.Scope == "baseline" ? 1 : manifest.SelectedCases.Length + 1;
        LiveEnvironment.Require(cases.Count == expected && cases.Select(c => c.Name).Distinct().Count() == expected && cases.All(c => c.Passed),
            "C02_CASE_COVERAGE_INCOMPLETE");
        foreach (var category in new[] { "user-disable", "token-revocation", "tenant-disable" }
            .Where(c => manifest.Includes("timed-" + c)))
        {
            var group = samples.Where(s => s.Category == category).ToArray();
            LiveEnvironment.Require(group.Length >= 100 && group.Count(s => s.Passed && s.TotalMilliseconds <= 30000) >= Math.Ceiling(group.Length * .99),
                "C02_TIMING_COVERAGE_INCOMPLETE");
        }
        complete = true;
    }
    public void Save()
    {
        Directory.CreateDirectory(manifest.PublicRoot);
        var failed = cases.Count(x => !x.Passed);
        var groups = samples.GroupBy(x => x.Category).Select(group =>
        {
            var ordered = group.Where(x => x.Passed).Select(x => x.TotalMilliseconds).Order().ToArray();
            return new { category = group.Key, count = group.Count(), failures = group.Count(x => !x.Passed),
                within30Seconds = group.Count(x => x.Passed && x.TotalMilliseconds <= 30000),
                p99Milliseconds = ordered.Length == 0 ? (double?)null : ordered[(int)Math.Ceiling(ordered.Length * .99) - 1] };
        }).ToArray();
        Write("summary.json", new { schemaId = "cp6.crm.c02-real-transport.v1", conclusion = complete && failed == 0 ? "success" : "failure",
            scope = manifest.Scope, verificationKind = "local published Release Core/CRM APIs, production Next/Vue, real SQL, native password/PKCE and Dapr/Kafka; not a production deployment",
            manifest.CoreSourceSha, manifest.CrmSourceSha, contractBundleSha256 = IdentityEventConsumer.BundleSha256,
            crmApiAssemblySha256 = Hash(manifest.CrmApiAssembly),
            crmInfrastructureAssemblySha256 = Hash(Path.Combine(Path.GetDirectoryName(manifest.CrmApiAssembly)!, "CP6.CRM.Infrastructure.dll")),
            total = cases.Count, passed = cases.Count(x => x.Passed), failed, skipped = 0, cases, groups, observations, observedAtUtc = DateTimeOffset.UtcNow });
        Write("latency-samples.json", samples);
        var xml = new StringBuilder($"<testsuite name=\"c02-real-transport\" tests=\"{cases.Count}\" failures=\"{failed}\" skipped=\"0\">\n");
        foreach (var item in cases) xml.Append($"  <testcase name=\"{SecurityElement.Escape(item.Name)}\">{(item.Passed ? "" : "<failure message=\"Actual transport requirement failed; original private diagnostics retained.\" />")}</testcase>\n");
        File.WriteAllText(Path.Combine(manifest.PublicRoot, "junit.xml"), xml.Append("</testsuite>\n").ToString());
    }
    private void Write(string name, object value) => File.WriteAllText(Path.Combine(manifest.PublicRoot, name), JsonSerializer.Serialize(value, LiveJson.Options));
    private static string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
    private sealed record CaseResult(string Name, bool Passed, DateTimeOffset StartedAtUtc, DateTimeOffset FinishedAtUtc);
}

internal sealed record LatencySample(string Category, int Sample, DateTimeOffset TriggerStartedAtUtc,
    DateTimeOffset BusinessResponseAtUtc, DateTimeOffset? OutboxPublishedAtUtc, DateTimeOffset? InboxProcessedAtUtc,
    DateTimeOffset? SessionDeletionObservedAtUtc, DateTimeOffset? DenialAtUtc, int? HttpStatus, bool Passed,
    double TotalMilliseconds, string? FailureCode);
