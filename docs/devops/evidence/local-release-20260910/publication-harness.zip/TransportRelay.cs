using System.Collections.Concurrent;
using System.Net;
using System.Text.Json;

namespace CP6.CRM.C02Acceptance;

// A transport-only fault relay: all discovery and event processing run in the actual
// CRM application. It can withhold one completed callback response before Dapr sees it.
internal sealed class TransportRelay(RunManifest manifest) : IAsyncDisposable
{
    private readonly HttpClient http = new(new SocketsHttpHandler { AllowAutoRedirect = false, UseCookies = false }) { Timeout = TimeSpan.FromSeconds(30) };
    private readonly ConcurrentDictionary<string, int> successes = [];
    private readonly ConcurrentDictionary<string, string> outcomes = [];
    private WebApplication? app;
    private string? dropMessage;
    private TaskCompletionSource? committed;
    private TaskCompletionSource? release;
    public int SuccessCount(string id) => successes.GetValueOrDefault(id);
    public string? Outcome(string id) => outcomes.GetValueOrDefault(id);
    public Task ArmAckLoss(string id)
    {
        dropMessage = id; committed = new(TaskCreationOptions.RunContinuationsAsynchronously);
        release = new(TaskCreationOptions.RunContinuationsAsynchronously); return committed.Task;
    }
    public void ReleaseLostAck() => release?.TrySetResult();
    public async Task StartAsync()
    {
        var builder = WebApplication.CreateBuilder(new WebApplicationOptions { Args = [], EnvironmentName = "Development" });
        builder.Logging.ClearProviders();
        builder.WebHost.ConfigureKestrel(k => k.Listen(IPAddress.Any, manifest.RelayPort));
        app = builder.Build();
        app.MapMethods("/{**path}", ["GET", "POST"], async context =>
        {
            if (context.Request.Path != "/dapr/subscribe" && context.Request.Path != "/dapr/config" && context.Request.Path != "/internal/crm/identity/events")
            { context.Response.StatusCode = 404; return; }
            using var body = new MemoryStream(); await context.Request.Body.CopyToAsync(body);
            var bytes = body.ToArray();
            using var request = new HttpRequestMessage(new HttpMethod(context.Request.Method),
                "http://127.0.0.1:" + manifest.CrmCallbackPort + context.Request.Path + context.Request.QueryString);
            if (bytes.Length > 0) request.Content = new ByteArrayContent(bytes);
            foreach (var header in context.Request.Headers)
                if (!new[] { "Host", "Connection", "Content-Length", "Transfer-Encoding" }.Contains(header.Key, StringComparer.OrdinalIgnoreCase))
                    if (!request.Headers.TryAddWithoutValidation(header.Key, header.Value.ToArray()))
                        request.Content?.Headers.TryAddWithoutValidation(header.Key, header.Value.ToArray());
            try
            {
                using var response = await http.SendAsync(request, context.RequestAborted);
                var result = await response.Content.ReadAsByteArrayAsync(context.RequestAborted);
                if (context.Request.Path == "/internal/crm/identity/events" && response.IsSuccessStatusCode)
                {
                    using var value = JsonDocument.Parse(bytes);
                    using var outcome = JsonDocument.Parse(result);
                    var id = value.RootElement.GetProperty("id").GetString()!;
                    var status = outcome.RootElement.GetProperty("status").GetString()!;
                    outcomes[id] = status;
                    if (status == "SUCCESS")
                    {
                        successes.AddOrUpdate(id, 1, (_, count) => count + 1);
                        if (id == dropMessage)
                        {
                            dropMessage = null; committed!.TrySetResult();
                            await release!.Task.WaitAsync(TimeSpan.FromSeconds(30));
                            context.Abort(); return;
                        }
                    }
                }
                context.Response.StatusCode = (int)response.StatusCode;
                context.Response.ContentType = response.Content.Headers.ContentType?.ToString();
                await context.Response.Body.WriteAsync(result, context.RequestAborted);
            }
            catch (Exception error) when (error is HttpRequestException or OperationCanceledException)
            { if (!context.RequestAborted.IsCancellationRequested) context.Response.StatusCode = 503; }
        });
        await app.StartAsync();
    }
    public async ValueTask DisposeAsync()
    {
        release?.TrySetResult();
        if (app is not null) { await app.StopAsync(); await app.DisposeAsync(); app = null; }
        http.Dispose();
    }
}
