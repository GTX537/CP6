package sample.empaccount;

import javax.ejb.Local;

import sample.empaccount.entity.EmpAccount;

@Local
public interface EmpAccountService {

    public EmpAccount findEmpAccount(Long empId);
    public String makeXML(EmpAccount empAccount);
    public void save(EmpAccount empAccount);
    public void commitEmpAccount(Long appRecepNo, String status);
}
