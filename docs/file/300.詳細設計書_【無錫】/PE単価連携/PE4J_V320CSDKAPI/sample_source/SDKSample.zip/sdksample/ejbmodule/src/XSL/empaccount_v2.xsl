<?xml version="1.0" encoding="utf-8" ?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://www.w3.org/1999/xhtml" version="1.0">
<xsl:output method="xml" encoding="utf-8" />

<xsl:template match="/">
    <xsl:apply-templates select="U_EMPACCOUNT" />
</xsl:template>

<xsl:template match="U_EMPACCOUNT">
	お申し込み
	<div class="contents">
        <xsl:apply-templates select="./REQUEST" />
    </div>
    <div style="margin-top:5px">現在のお届け情報</div>
	<div class="contents">
        <xsl:apply-templates select="./PRESENT" />
    </div>
</xsl:template>

<xsl:template match="PRESENT">
    <xsl:apply-templates select="./SALARY" />
    <xsl:apply-templates select="./BONUS" />
</xsl:template>

<xsl:template match="REQUEST">
    <xsl:apply-templates select="./SALARY" />
    <xsl:apply-templates select="./BONUS" />
</xsl:template>

<xsl:template match="SALARY">
    ＜給与第一口座＞
    <xsl:apply-templates select="./FIRST" />
    ＜給与第二口座＞
    <xsl:apply-templates select="./SECOND" />
</xsl:template>

<xsl:template match="BONUS">
    ＜賞与第一口座＞
    <xsl:apply-templates select="./FIRST" />
    ＜賞与第二口座＞
    <xsl:apply-templates select="./SECOND" />
</xsl:template>

<xsl:template match="FIRST">
    <table class="detail">
        <tr>
            <td class="label">銀行・支店</td>
            <td class="item">
            <xsl:if test="BANKNAME!='' or BRANCHNAME!=''">
                    <xsl:if test="BANKNAME!=''">
                        <xsl:value-of select="./BANKNAME" />
                        <xsl:text> </xsl:text>
                    </xsl:if>
                    <xsl:if test="BRANCHNAME!=''">
                        <xsl:value-of select="./BRANCHNAME" />
                    </xsl:if>
            </xsl:if>
            </td>
        </tr>
        <tr>
            <td class="label">預金種目・口座番号</td>
            <td class="item">
            <xsl:if test="DEPOSITTYPE!='' or ACCOUNTNO!=''">
                    <xsl:if test="DEPOSITTYPE!=''">
                        <xsl:value-of select="./DEPOSITTYPE" /><xsl:text>　</xsl:text>
                    </xsl:if>
                    <xsl:if test="ACCOUNTNO!=''">
                        <xsl:value-of select="./ACCOUNTNO" />
                    </xsl:if>
            </xsl:if>
            </td>
        </tr>
    </table>
</xsl:template>

<xsl:template match="SECOND">
    <table class="detail">
        <tr>
            <td class="label">銀行・支店</td>
            <td class="item">
            <xsl:if test="BANKNAME!='' or BRANCHNAME!=''">
                    <xsl:if test="BANKNAME!=''">
                        <xsl:value-of select="./BANKNAME" />
                        <xsl:text> </xsl:text>
                    </xsl:if>
                    <xsl:if test="BRANCHNAME!=''">
                        <xsl:value-of select="./BRANCHNAME" />
                    </xsl:if>
            </xsl:if>
            </td>
        </tr>
        <tr>
            <td class="label">預金種目・口座番号</td>
            <td class="item">
            <xsl:if test="DEPOSITTYPE!='' or ACCOUNTNO!=''">
                    <xsl:if test="DEPOSITTYPE!=''">
                        <xsl:value-of select="./DEPOSITTYPE" /><xsl:text>　</xsl:text>
                    </xsl:if>
                    <xsl:if test="ACCOUNTNO!=''">
                        <xsl:value-of select="./ACCOUNTNO" />
                    </xsl:if>
            </xsl:if>
            </td>
        </tr>
        <tr>
            <td class="label">振込額</td>
            <td class="item">
            <xsl:if test="FIXEDAMOUNT!=''">
                <xsl:value-of select="./FIXEDAMOUNT" />
            </xsl:if>
            </td>
        </tr>
    </table>
</xsl:template>

</xsl:stylesheet>
