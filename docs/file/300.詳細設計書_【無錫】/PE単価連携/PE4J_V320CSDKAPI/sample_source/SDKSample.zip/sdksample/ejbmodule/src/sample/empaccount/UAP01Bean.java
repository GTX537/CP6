package sample.empaccount;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.enterprise.context.ConversationScoped;
import javax.faces.model.SelectItem;
import javax.inject.Inject;
import javax.inject.Named;

import net.poweregg.annotations.Login;
import net.poweregg.annotations.PEIntercepter;
import net.poweregg.common.ClassificationService;
import net.poweregg.common.entity.ClassInfo;
import net.poweregg.dataflow.ApplyException;
import net.poweregg.dataflow.ConstStatus;
import net.poweregg.dataflow.DataflowHelperBean;
import net.poweregg.exkeihi.entity.Bank;
import net.poweregg.exkeihi.ui.param.BankParam;
import net.poweregg.organization.OrganizationService;
import net.poweregg.organization.entity.Employee;
import net.poweregg.seam.faces.FacesMessages;
import net.poweregg.web.engine.navigation.LoginUser;
import sample.empaccount.entity.EmpAccount;

/**
 * サンプルアプリケーション 給与振込口座申請 アプリケーションビーン
 *
 * Copyright(C) 2016 D-CIRCLE, INC.
 * All rights reserved.
 */
@Named("UAP01Bean")
@ConversationScoped
@PEIntercepter
public class UAP01Bean implements Serializable {

    private static final long serialVersionUID = 6348982803040318105L;

    @Inject @Login
    private LoginUser loginUser;

    @Inject
    private DataflowHelperBean dataflowHelper;

    @Inject
    private transient FacesMessages facesMessages;

    private EmpAccount empAccount = null;

    private BankParam applySalaryBank1Param;
    private BankParam applySalaryBank2Param;
    private BankParam applyBonusBank1Param;
    private BankParam applyBonusBank2Param;

    @EJB
    EmpAccountService empAccountService;

    @EJB
    OrganizationService organizationService;

    @EJB
    ClassificationService classificationService;

    Employee employee;

    SelectItem[] depositTypes;

    // 申請受付番号
    private Long appRecepNo;

    private boolean initialized = false;

    public void initialize() {
        if (!initialized) {
            empAccount = empAccountService.findEmpAccount(loginUser.getEmpID());
            if (empAccount == null) {
                empAccount = new EmpAccount(loginUser.getEmpID());
            }
            applySalaryBank1Param = bank2BankParam(empAccount.getApplySalaryBank1());
            applySalaryBank2Param = bank2BankParam(empAccount.getApplySalaryBank2());
            applyBonusBank1Param = bank2BankParam(empAccount.getApplyBonusBank1());
            applyBonusBank2Param = bank2BankParam(empAccount.getApplyBonusBank2());
            employee = organizationService.findEmployee(loginUser.getEmpID());
            depositTypes = createDepositeTypes();
            initialized = true;
        }
    }

    private BankParam bank2BankParam(Bank bank) {
        if (bank == null) {
            return null;
        }
        BankParam bp = new BankParam();
        bp.setValueBankCode(bank.getBankCode());
        bp.setValueBranchCode(bank.getBranchCode());
        bp.setValueBankName(bank.getBankName());
        bp.setValueBranchName(bank.getBranchName());
        return bp;
    }

    private Bank bankParam2Bank(BankParam bankParam) {
        if (bankParam == null) {
            return null;
        }
        Bank bank = new Bank();
        bank.setBankCode(bankParam.getValueBankCode());
        bank.setBranchCode(bankParam.getValueBranchCode());
        bank.setBankName(bankParam.getValueBankName());
        bank.setBranchName(bankParam.getValueBranchName());
        return bank;
    }

    private SelectItem[] createDepositeTypes() {
        List<ClassInfo> list = classificationService.getClassInfoList("0000000000", "1428");
        SelectItem[] items = new SelectItem[list.size()];
        for (int i=0;i<list.size();i++) {
            ClassInfo info = list.get(i);
            SelectItem item=new SelectItem(info.getClassno(), info.getClassName());
            items[i] = item;
        }
        return items;
    }

    public boolean isCanApply() {
        if (empAccount != null && empAccount.getApplicationStatus() != null) {
            String appStatus = empAccount.getApplicationStatus().getStatus();
            if (ConstStatus.STATUS_UNDER_DELIBERATION.equals(appStatus)) {
                return false;
            } else {
                return true;
            }
        } else {
            // 未申請の場合は常に申請可能
            return true;
        }
    }
    /**
     * 確認ボタン押下時のアクション.
     * @return "confirm"
     */
    public String toConfirm() {

        //銀行変換
        empAccount.setApplySalaryBank1(bankParam2Bank(applySalaryBank1Param));
        empAccount.setApplySalaryBank2(bankParam2Bank(applySalaryBank2Param));
        empAccount.setApplyBonusBank1(bankParam2Bank(applyBonusBank1Param));
        empAccount.setApplyBonusBank2(bankParam2Bank(applyBonusBank2Param));

        // ワークフローパラメタ編集
        dataflowHelper.setApplyDate(getToday());
        dataflowHelper.setTitle("振込口座申請：" + loginUser.getEmpName());
        dataflowHelper.setBaseForm("9100");
        dataflowHelper.setApplicant(loginUser.getCorpID(), loginUser.getDeptID(), loginUser.getEmpID());
        dataflowHelper.setApplyCondition("1");
        dataflowHelper.setApplyContent(empAccountService.makeXML(empAccount));
        dataflowHelper.setRouteEdit(true);  // ルート変更可能に設定
        dataflowHelper.setXslFileName("empaccount_v2.xsl");

        // 申請受付番号がすでに存在し、再申請可能な場合は、
        // 既存の受付番号を利用する.
        if (empAccount.getAppRecepNo() != null
                && empAccount.getApplicationStatus().isReAppliable() == true) {
            dataflowHelper.setAppRecpNo(empAccount.getAppRecepNo());
        }

        try {
            appRecepNo = dataflowHelper.prepareApply();
            facesMessages.add("申請してよろしいですか？");
            return "confirm";
        } catch (ApplyException e) {
            return null;
        }
    }

    private Date getToday() {
        GregorianCalendar calelder = new GregorianCalendar();
        calelder.setTime(new Date());
        calelder.set(Calendar.HOUR_OF_DAY, 0);
        calelder.set(Calendar.MINUTE, 0);
        calelder.set(Calendar.SECOND, 0);
        calelder.set(Calendar.MILLISECOND, 0);
        return calelder.getTime();
    }

    /**
     * 申請ボタン押下時のアクション.
     * @return "apply"
     */
    public String apply() {

        try {
            // 申請確定
            dataflowHelper.apply();
            // 自分のデータを保存する.
            empAccount.setAppRecepNo(appRecepNo);
            empAccountService.save(empAccount);

            facesMessages.add("申請しました。");

            // 再初期化
            initialize();

            return "apply";
        } catch (ApplyException ex) {
            return null;
        }
    }

    /**
     * 取り下げボタン押下時のアクション.
     * @return "withdraw"
     */
    public String withdraw() {
        return "withdraw";
    }

    /**
     * 戻るボタン押下時のアクション.
     * @return "return"
     */
    public String toReturn() {
        return "return";
    }

    @PreDestroy
    public void destroy() {
    }

    public EmpAccount getEmpAccount() {
        return empAccount;
    }

    public void setEmpAccount(EmpAccount empAccount) {
        this.empAccount = empAccount;
    }

    public BankParam getApplySalaryBank1Param() {
        return applySalaryBank1Param;
    }

    public void setApplySalaryBank1Param(BankParam applySalaryBank1Param) {
        this.applySalaryBank1Param = applySalaryBank1Param;
    }

    public BankParam getApplySalaryBank2Param() {
        return applySalaryBank2Param;
    }

    public void setApplySalaryBank2Param(BankParam applySalaryBank2Param) {
        this.applySalaryBank2Param = applySalaryBank2Param;
    }

    public BankParam getApplyBonusBank1Param() {
        return applyBonusBank1Param;
    }

    public void setApplyBonusBank1Param(BankParam applyBonusBank1Param) {
        this.applyBonusBank1Param = applyBonusBank1Param;
    }

    public BankParam getApplyBonusBank2Param() {
        return applyBonusBank2Param;
    }

    public void setApplyBonusBank2Param(BankParam applyBonusBank2Param) {
        this.applyBonusBank2Param = applyBonusBank2Param;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public SelectItem[] getDepositTypes() {
        return depositTypes;
    }

    public void setDepositTypes(SelectItem[] depositTypes) {
        this.depositTypes = depositTypes;
    }
}
