package sample.empaccount.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Version;

import net.poweregg.dataflow.entity.ApplicationStatus;
import net.poweregg.exkeihi.entity.Bank;
import net.poweregg.organization.entity.Corporation;
import net.poweregg.organization.entity.Employee;

/**
 * POWER EGG V2.0 SDKサンプルアプリケーション
 * 給与振込口座申請 社員銀行口座エンティティ
 * Copyright(C) 2016 D-CIRCLE, INC. All rights reserved.
 */
@Entity
@Table(name="ut2_emp_account")
public class EmpAccount implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="empid")
    private Long empId;

    @ManyToOne
    @JoinColumn(name="empid",insertable=false,updatable=false)
    private Employee employee;

    @ManyToOne
    @JoinColumn(name="corpid")
    private Corporation corporation;

    @Column(name="apprecepno")
    private Long appRecepNo;

    @OneToOne
    @JoinColumn(name="apprecepno",insertable=false,updatable=false)
    private ApplicationStatus applicationStatus;


    @ManyToOne(fetch = FetchType.EAGER,targetEntity=Bank.class)
    @JoinColumns({
            @JoinColumn(name="psbankcode1",referencedColumnName="bankcode"),
            @JoinColumn(name="psbranchcode1",referencedColumnName="branchcode")
            })
    private Bank currentSalaryBank1;

    @Column(name="psdeposittype1")
    private String currentSalaryDepositeType1;

    @Transient
    private String currentSalaryDepositeTypeName1;

    @Column(name="psaccountno1")
    private String currentSalaryAccountNo1;

    @ManyToOne(fetch = FetchType.EAGER,targetEntity=Bank.class)
    @JoinColumns({
            @JoinColumn(name="psbankcode2",referencedColumnName="bankcode"),
            @JoinColumn(name="psbranchcode2",referencedColumnName="branchcode")
            })
    private Bank currentSalaryBank2;

    @Column(name="psdeposittype2")
    private String currentSalaryDepositeType2;

    @Transient
    private String currentSalaryDepositeTypeName2;

    @Column(name="psaccountno2")
    private String currentSalaryAccountNo2;

    @Column(name="psfixedamount")
    private BigDecimal currentSalaryFixedAmmount;

    @ManyToOne(fetch = FetchType.EAGER,targetEntity=Bank.class)
    @JoinColumns({
            @JoinColumn(name="pbbankcode1",referencedColumnName="bankcode"),
            @JoinColumn(name="pbbranchcode1",referencedColumnName="branchcode")
            })
    private Bank currentBonusBank1;

    @Column(name="pbdeposittype1")
    private String currentBonusDepositeType1;


    @Transient
    private String currentBonusDepositeTypeName1;

    @Column(name="pbaccountno1")
    private String currentBonusAccountNo1;

    @ManyToOne(fetch = FetchType.EAGER,targetEntity=Bank.class)
    @JoinColumns({
            @JoinColumn(name="pbbankcode2",referencedColumnName="bankcode"),
            @JoinColumn(name="pbbranchcode2",referencedColumnName="branchcode")
            })
    private Bank currentBonusBank2;

    @Column(name="pbdeposittype2")
    private String currentBonusDepositeType2;

    @Transient
    private String currentBonusDepositeTypeName2;

    @Column(name="pbaccountno2")
    private String currentBonusAccountNo2;

    @Column(name="pbfixedamount")
    private BigDecimal currentBonusFixedAmmount;

    // 申込情報
    @ManyToOne(fetch = FetchType.EAGER,targetEntity=Bank.class)
    @JoinColumns({
            @JoinColumn(name="asbankcode1",referencedColumnName="bankcode"),
            @JoinColumn(name="asbranchcode1",referencedColumnName="branchcode")
            })
    private Bank applySalaryBank1;

    @Column(name="asdeposittype1")
    private String applySalaryDepositeType1;

    @Transient
    private String applySalaryDepositeTypeName1;

    @Column(name="asaccountno1")
    private String applySalaryAccountNo1;

    @ManyToOne(fetch = FetchType.EAGER,targetEntity=Bank.class)
    @JoinColumns({
            @JoinColumn(name="asbankcode2",referencedColumnName="bankcode"),
            @JoinColumn(name="asbranchcode2",referencedColumnName="branchcode")
            })
    private Bank applySalaryBank2;

    @Column(name="asdeposittype2")
    private String applySalaryDepositeType2;

    @Transient
    private String applySalaryDepositeTypeName2;

    @Column(name="asaccountno2")
    private String applySalaryAccountNo2;

    @Column(name="asfixedamount")
    private BigDecimal applySalaryFixedAmmount;


    @ManyToOne(fetch = FetchType.EAGER,targetEntity=Bank.class)
    @JoinColumns({
            @JoinColumn(name="abbankcode1",referencedColumnName="bankcode"),
            @JoinColumn(name="abbranchcode1",referencedColumnName="branchcode")
            })
    private Bank applyBonusBank1;

    @Column(name="abdeposittype1")
    private String applyBonusDepositeType1;

    @Transient
    private String applyBonusDepositeTypeName1;

    @Column(name="abaccountno1")
    private String applyBonusAccountNo1;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumns({
            @JoinColumn(name="abbankcode2",referencedColumnName="bankcode"),
            @JoinColumn(name="abbranchcode2",referencedColumnName="branchcode")
            })
    private Bank applyBonusBank2;

    @Column(name="abdeposittype2")
    private String applyBonusDepositeType2;

    @Transient
    private String applyBonusDepositeTypeName2;

    @Column(name="abaccountno2")
    private String applyBonusAccountNo2;

    @Column(name="abfixedamount")
    private BigDecimal applyBonusFixedAmmount;

    @Version
    private long updateCounter;

    @Column(name="lastupdate")
    private Timestamp lastUpdate;

    public EmpAccount() {

    }

    public EmpAccount(Long empId) {
        this.empId = empId;
    }

    @PrePersist
    @PreUpdate
    void syncLastUpdate() {
        this.lastUpdate = new Timestamp(System.currentTimeMillis());
    }

    public Long getEmpId() {
        return empId;
    }

    public void setEmpId(Long empId) {
        this.empId = empId;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Corporation getCorporation() {
        return corporation;
    }

    public void setCorporation(Corporation corporation) {
        this.corporation = corporation;
    }

    public Long getAppRecepNo() {
        return appRecepNo;
    }

    public void setAppRecepNo(Long appRecepNo) {
        this.appRecepNo = appRecepNo;
    }

    public ApplicationStatus getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(ApplicationStatus applicationStatus) {
        this.applicationStatus = applicationStatus;
    }

    public Bank getCurrentSalaryBank1() {
        return currentSalaryBank1;
    }

    public void setCurrentSalaryBank1(Bank currentSalaryBank1) {
        this.currentSalaryBank1 = currentSalaryBank1;
    }

    public String getCurrentSalaryDepositeType1() {
        return currentSalaryDepositeType1;
    }

    public void setCurrentSalaryDepositeType1(String currentSalaryDepositeType1) {
        this.currentSalaryDepositeType1 = currentSalaryDepositeType1;
    }

    public String getCurrentSalaryAccountNo1() {
        return currentSalaryAccountNo1;
    }

    public void setCurrentSalaryAccountNo1(String currentSalaryAccountNo1) {
        this.currentSalaryAccountNo1 = currentSalaryAccountNo1;
    }

    public Bank getCurrentSalaryBank2() {
        return currentSalaryBank2;
    }

    public void setCurrentSalaryBank2(Bank currentSalaryBank2) {
        this.currentSalaryBank2 = currentSalaryBank2;
    }

    public String getCurrentSalaryDepositeType2() {
        return currentSalaryDepositeType2;
    }

    public void setCurrentSalaryDepositeType2(String currentSalaryDepositeType2) {
        this.currentSalaryDepositeType2 = currentSalaryDepositeType2;
    }

    public String getCurrentSalaryAccountNo2() {
        return currentSalaryAccountNo2;
    }

    public void setCurrentSalaryAccountNo2(String currentSalaryAccountNo2) {
        this.currentSalaryAccountNo2 = currentSalaryAccountNo2;
    }

    public BigDecimal getCurrentSalaryFixedAmmount() {
        return currentSalaryFixedAmmount;
    }

    public void setCurrentSalaryFixedAmmount(BigDecimal currentSalaryFixedAmmount) {
        this.currentSalaryFixedAmmount = currentSalaryFixedAmmount;
    }

    public Bank getCurrentBonusBank1() {
        return currentBonusBank1;
    }

    public void setCurrentBonusBank1(Bank currentBonusBank1) {
        this.currentBonusBank1 = currentBonusBank1;
    }

    public String getCurrentBonusDepositeType1() {
        return currentBonusDepositeType1;
    }

    public void setCurrentBonusDepositeType1(String currentBonusDepositeType1) {
        this.currentBonusDepositeType1 = currentBonusDepositeType1;
    }

    public String getCurrentBonusAccountNo1() {
        return currentBonusAccountNo1;
    }

    public void setCurrentBonusAccountNo1(String currentBonusAccountNo1) {
        this.currentBonusAccountNo1 = currentBonusAccountNo1;
    }

    public Bank getCurrentBonusBank2() {
        return currentBonusBank2;
    }

    public void setCurrentBonusBank2(Bank currentBonusBank2) {
        this.currentBonusBank2 = currentBonusBank2;
    }

    public String getCurrentBonusDepositeType2() {
        return currentBonusDepositeType2;
    }

    public void setCurrentBonusDepositeType2(String currentBonusDepositeType2) {
        this.currentBonusDepositeType2 = currentBonusDepositeType2;
    }

    public String getCurrentBonusAccountNo2() {
        return currentBonusAccountNo2;
    }

    public void setCurrentBonusAccountNo2(String currentBonusAccountNo2) {
        this.currentBonusAccountNo2 = currentBonusAccountNo2;
    }

    public BigDecimal getCurrentBonusFixedAmmount() {
        return currentBonusFixedAmmount;
    }

    public void setCurrentBonusFixedAmmount(BigDecimal currentBonusFixedAmmount) {
        this.currentBonusFixedAmmount = currentBonusFixedAmmount;
    }

    public Bank getApplySalaryBank1() {
        return applySalaryBank1;
    }

    public void setApplySalaryBank1(Bank applySalaryBank1) {
        this.applySalaryBank1 = applySalaryBank1;
    }

    public String getApplySalaryDepositeType1() {
        return applySalaryDepositeType1;
    }

    public void setApplySalaryDepositeType1(String applySalaryDepositeType1) {
        this.applySalaryDepositeType1 = applySalaryDepositeType1;
    }

    public String getApplySalaryAccountNo1() {
        return applySalaryAccountNo1;
    }

    public void setApplySalaryAccountNo1(String applySalaryAccountNo1) {
        this.applySalaryAccountNo1 = applySalaryAccountNo1;
    }

    public Bank getApplySalaryBank2() {
        return applySalaryBank2;
    }

    public void setApplySalaryBank2(Bank applySalaryBank2) {
        this.applySalaryBank2 = applySalaryBank2;
    }

    public String getApplySalaryDepositeType2() {
        return applySalaryDepositeType2;
    }

    public void setApplySalaryDepositeType2(String applySalaryDepositeType2) {
        this.applySalaryDepositeType2 = applySalaryDepositeType2;
    }

    public String getApplySalaryAccountNo2() {
        return applySalaryAccountNo2;
    }

    public void setApplySalaryAccountNo2(String applySalaryAccountNo2) {
        this.applySalaryAccountNo2 = applySalaryAccountNo2;
    }

    public BigDecimal getApplySalaryFixedAmmount() {
        return applySalaryFixedAmmount;
    }

    public void setApplySalaryFixedAmmount(BigDecimal applySalaryFixedAmmount) {
        this.applySalaryFixedAmmount = applySalaryFixedAmmount;
    }

    public Bank getApplyBonusBank1() {
        return applyBonusBank1;
    }

    public void setApplyBonusBank1(Bank applyBonusBank1) {
        this.applyBonusBank1 = applyBonusBank1;
    }

    public String getApplyBonusDepositeType1() {
        return applyBonusDepositeType1;
    }

    public void setApplyBonusDepositeType1(String applyBonusDepositeType1) {
        this.applyBonusDepositeType1 = applyBonusDepositeType1;
    }

    public String getApplyBonusAccountNo1() {
        return applyBonusAccountNo1;
    }

    public void setApplyBonusAccountNo1(String applyBonusAccountNo1) {
        this.applyBonusAccountNo1 = applyBonusAccountNo1;
    }

    public Bank getApplyBonusBank2() {
        return applyBonusBank2;
    }

    public void setApplyBonusBank2(Bank applyBonusBank2) {
        this.applyBonusBank2 = applyBonusBank2;
    }

    public String getApplyBonusDepositeType2() {
        return applyBonusDepositeType2;
    }

    public void setApplyBonusDepositeType2(String applyBonusDepositeType2) {
        this.applyBonusDepositeType2 = applyBonusDepositeType2;
    }

    public String getApplyBonusAccountNo2() {
        return applyBonusAccountNo2;
    }

    public void setApplyBonusAccountNo2(String applyBonusAccountNo2) {
        this.applyBonusAccountNo2 = applyBonusAccountNo2;
    }

    public BigDecimal getApplyBonusFixedAmmount() {
        return applyBonusFixedAmmount;
    }

    public void setApplyBonusFixedAmmount(BigDecimal applyBonusFixedAmmount) {
        this.applyBonusFixedAmmount = applyBonusFixedAmmount;
    }

    public long getUpdateCounter() {
        return updateCounter;
    }

    public void setUpdateCounter(long updateCounter) {
        this.updateCounter = updateCounter;
    }

    public Timestamp getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Timestamp lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getCurrentSalaryDepositeTypeName1() {
        return currentSalaryDepositeTypeName1;
    }

    public void setCurrentSalaryDepositeTypeName1(
            String currentSalaryDepositeTypeName1) {
        this.currentSalaryDepositeTypeName1 = currentSalaryDepositeTypeName1;
    }

    public String getCurrentSalaryDepositeTypeName2() {
        return currentSalaryDepositeTypeName2;
    }

    public void setCurrentSalaryDepositeTypeName2(
            String currentSalaryDepositeTypeName2) {
        this.currentSalaryDepositeTypeName2 = currentSalaryDepositeTypeName2;
    }

    public String getCurrentBonusDepositeTypeName1() {
        return currentBonusDepositeTypeName1;
    }

    public void setCurrentBonusDepositeTypeName1(
            String currentBonusDepositeTypeName1) {
        this.currentBonusDepositeTypeName1 = currentBonusDepositeTypeName1;
    }

    public String getCurrentBonusDepositeTypeName2() {
        return currentBonusDepositeTypeName2;
    }

    public void setCurrentBonusDepositeTypeName2(
            String currentBonusDepositeTypeName2) {
        this.currentBonusDepositeTypeName2 = currentBonusDepositeTypeName2;
    }

    public String getApplySalaryDepositeTypeName1() {
        return applySalaryDepositeTypeName1;
    }

    public void setApplySalaryDepositeTypeName1(String applySalaryDepositeTypeName1) {
        this.applySalaryDepositeTypeName1 = applySalaryDepositeTypeName1;
    }

    public String getApplySalaryDepositeTypeName2() {
        return applySalaryDepositeTypeName2;
    }

    public void setApplySalaryDepositeTypeName2(String applySalaryDepositeTypeName2) {
        this.applySalaryDepositeTypeName2 = applySalaryDepositeTypeName2;
    }

    public String getApplyBonusDepositeTypeName1() {
        return applyBonusDepositeTypeName1;
    }

    public void setApplyBonusDepositeTypeName1(String applyBonusDepositeTypeName1) {
        this.applyBonusDepositeTypeName1 = applyBonusDepositeTypeName1;
    }

    public String getApplyBonusDepositeTypeName2() {
        return applyBonusDepositeTypeName2;
    }

    public void setApplyBonusDepositeTypeName2(String applyBonusDepositeTypeName2) {
        this.applyBonusDepositeTypeName2 = applyBonusDepositeTypeName2;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (empId != null ? empId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof EmpAccount)) {
            return false;
        }
        EmpAccount other = (EmpAccount) object;
        if ((this.empId == null && other.empId != null)
                || (this.empId != null && !this.empId.equals(other.empId))) {
            return false;
        }
        if (this.empId.equals(other.empId)) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        return "EmpAccount[empid=" + empId +"]";
    }

}
