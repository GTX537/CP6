package sample.empaccount;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import net.poweregg.dataflow.IProcAfterFlow;

/**
 * POWER EGG V2.0 SDKサンプルアプリケーション
 * 給与振込口座申請 事後処理
 * Copyright(C) 2006 D-CIRCLE, INC. All rights reserved.
 */
public class UAP01AfterFlow implements IProcAfterFlow {

    /**
     * デフォルトコンストラクタ
     */
    public UAP01AfterFlow()  {
        super();
    }

    /**
     * データフローから呼び出される事後処理のビジネスロジックです。<BR>
     * このメソッドはJTAトランザクションスコープ内で呼び出されますので<BR>
     * トランザクション命令を発行しないでください。
     * @param appRecepNo 申請受付番号
     * @param historyNo 履歴番号
     * @param status 決裁状況（IntAfterFlow インタフェース
     * 							に定数で定義されています）
     */
    public void doProcess(Long appRecepNo, Integer historyNo, String status) {

        try {
            InitialContext icx = new InitialContext();
            String service_jndi = getLookupName(icx, "empAccount-ejb", "EmpAccountServiceBean");
            EmpAccountService service = (EmpAccountService)icx.lookup(service_jndi);
	        service.commitEmpAccount(appRecepNo, status);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
    private static String getLookupName (InitialContext icx, String moduleName, String className) throws NamingException {
        final String format = "java:global/%s/%s/%s";
        //アップリケーション名を取得する
        String appName = (String) icx.lookup("java:app/AppName");
        return String.format(format, appName, moduleName, className);
    }

}
