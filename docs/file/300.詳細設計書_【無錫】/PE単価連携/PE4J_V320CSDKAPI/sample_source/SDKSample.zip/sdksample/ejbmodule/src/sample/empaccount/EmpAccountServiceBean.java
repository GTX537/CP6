package sample.empaccount;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import net.poweregg.common.ClassificationService;
import net.poweregg.common.entity.ClassInfo;
import net.poweregg.util.PEStringUtilities;
import sample.empaccount.entity.EmpAccount;

@Stateless
public class EmpAccountServiceBean implements EmpAccountService {

    @PersistenceContext(unitName="pe4jPU")
    private EntityManager em;

    @EJB
    private ClassificationService classificationService;

    /**
     * 引数(obj)がNULLの場合に空文字を返す。
     *
     * @return java.lang.String
     */
    private String addEmpty(Object obj) {
        if (obj == null)
            return "";
        return PEStringUtilities.parseHtmlStringForXML(obj.toString());
    }

    /**
     * XML文字列を生成します。
     */
    public String makeXML(EmpAccount empAccount) {
        String xmlString = new String();
        xmlString = "";
        String CR_LF = System.getProperties().getProperty("line.separator");
        xmlString += "<?xml version=\"1.0\" encoding=\"utf-8\" ?>" + CR_LF;
        xmlString += "<U_EMPACCOUNT>" + CR_LF;
        xmlString += "<PRESENT>" + CR_LF;
        xmlString += "<SALARY>" + CR_LF;
        xmlString += "<FIRST>" + CR_LF;
        xmlString += "<BANKNAME>"
                + addEmpty(empAccount.getCurrentSalaryBank1() != null ? empAccount.getCurrentSalaryBank1().getBankName() : "")
                + "</BANKNAME>" + CR_LF;
        xmlString += "<BRANCHNAME>"
                + addEmpty(empAccount.getCurrentSalaryBank1() != null ? empAccount.getCurrentSalaryBank1().getBranchName() : "")
                + "</BRANCHNAME>" + CR_LF;
        xmlString += "<DEPOSITTYPE>"
                + addEmpty(empAccount.getCurrentSalaryDepositeTypeName1())
                + "</DEPOSITTYPE>" + CR_LF;
        xmlString += "<ACCOUNTNO>"
                + addEmpty(empAccount.getCurrentSalaryAccountNo1())
                + "</ACCOUNTNO>" + CR_LF;
        xmlString += "</FIRST>" + CR_LF;
        xmlString += "<SECOND>" + CR_LF;
        xmlString += "<BANKNAME>"
                + addEmpty(empAccount.getCurrentSalaryBank2() != null ? empAccount.getCurrentSalaryBank2().getBankName() : "")
                + "</BANKNAME>" + CR_LF;
        xmlString += "<BRANCHNAME>"
                + addEmpty(empAccount.getCurrentSalaryBank2() != null ? empAccount.getCurrentSalaryBank2().getBranchName() : "")
                + "</BRANCHNAME>" + CR_LF;
        xmlString += "<DEPOSITTYPE>"
                + addEmpty(empAccount.getCurrentSalaryDepositeTypeName2())
                + "</DEPOSITTYPE>" + CR_LF;
        xmlString += "<ACCOUNTNO>"
                + addEmpty(empAccount.getCurrentSalaryAccountNo2())
                + "</ACCOUNTNO>" + CR_LF;
        xmlString += "<FIXEDAMOUNT>"
                + PEStringUtilities.formatDigit(empAccount
                        .getCurrentSalaryFixedAmmount()) + "</FIXEDAMOUNT>"
                + CR_LF;
        xmlString += "</SECOND>" + CR_LF;
        xmlString += "</SALARY>" + CR_LF;
        xmlString += "<BONUS>" + CR_LF;
        xmlString += "<FIRST>" + CR_LF;
        xmlString += "<BANKNAME>"
                + addEmpty(empAccount.getCurrentBonusBank1() != null ? empAccount.getCurrentBonusBank1().getBankName() : "")
                + "</BANKNAME>" + CR_LF;
        xmlString += "<BRANCHNAME>"
                + addEmpty(empAccount.getCurrentBonusBank1() != null ? empAccount.getCurrentBonusBank1().getBranchName() : "")
                + "</BRANCHNAME>" + CR_LF;
        xmlString += "<DEPOSITTYPE>"
                + addEmpty(empAccount.getCurrentBonusDepositeTypeName1())
                + "</DEPOSITTYPE>" + CR_LF;
        xmlString += "<ACCOUNTNO>"
                + addEmpty(empAccount.getCurrentBonusAccountNo1())
                + "</ACCOUNTNO>" + CR_LF;
        xmlString += "</FIRST>" + CR_LF;
        xmlString += "<SECOND>" + CR_LF;
        xmlString += "<BANKNAME>"
                + addEmpty(empAccount.getCurrentBonusBank2() != null ? empAccount.getCurrentBonusBank2().getBankName() : "")
                + "</BANKNAME>" + CR_LF;
        xmlString += "<BRANCHNAME>"
                + addEmpty(empAccount.getCurrentBonusBank2() != null ? empAccount.getCurrentBonusBank2().getBranchName() : "")
                + "</BRANCHNAME>" + CR_LF;
        xmlString += "<DEPOSITTYPE>"
                + addEmpty(empAccount.getCurrentBonusDepositeTypeName2())
                + "</DEPOSITTYPE>" + CR_LF;
        xmlString += "<ACCOUNTNO>"
                + addEmpty(empAccount.getCurrentBonusAccountNo2())
                + "</ACCOUNTNO>" + CR_LF;
        xmlString += "<FIXEDAMOUNT>"
                + PEStringUtilities.formatDigit(empAccount
                        .getCurrentBonusFixedAmmount()) + "</FIXEDAMOUNT>"
                + CR_LF;
        xmlString += "</SECOND>" + CR_LF;
        xmlString += "</BONUS>" + CR_LF;
        xmlString += "</PRESENT>" + CR_LF;
        xmlString += "<REQUEST>" + CR_LF;
        xmlString += "<SALARY>" + CR_LF;
        xmlString += "<FIRST>" + CR_LF;
        xmlString += "<BANKNAME>"
                + addEmpty(empAccount.getApplySalaryBank1() != null ? empAccount.getApplySalaryBank1().getBankName() : "")
                + "</BANKNAME>" + CR_LF;
        xmlString += "<BRANCHNAME>"
                + addEmpty(empAccount.getApplySalaryBank1() != null ? empAccount.getApplySalaryBank1().getBranchName() : "")
                + "</BRANCHNAME>" + CR_LF;
        xmlString += "<DEPOSITTYPE>"
                + addEmpty(empAccount.getApplySalaryDepositeTypeName1())
                + "</DEPOSITTYPE>" + CR_LF;
        xmlString += "<ACCOUNTNO>"
                + addEmpty(empAccount.getApplySalaryAccountNo1())
                + "</ACCOUNTNO>" + CR_LF;
        xmlString += "</FIRST>" + CR_LF;
        xmlString += "<SECOND>" + CR_LF;
        xmlString += "<BANKNAME>"
                + addEmpty(empAccount.getApplySalaryBank2() != null ? empAccount.getApplySalaryBank2().getBankName() : "")
                + "</BANKNAME>" + CR_LF;
        xmlString += "<BRANCHNAME>"
                + addEmpty(empAccount.getApplySalaryBank2() != null ? empAccount.getApplySalaryBank2().getBranchName() : "")
                + "</BRANCHNAME>" + CR_LF;
        xmlString += "<DEPOSITTYPE>"
                + addEmpty(empAccount.getApplySalaryDepositeTypeName2())
                + "</DEPOSITTYPE>" + CR_LF;
        xmlString += "<ACCOUNTNO>"
                + addEmpty(empAccount.getApplySalaryAccountNo2())
                + "</ACCOUNTNO>" + CR_LF;
        xmlString += "<FIXEDAMOUNT>"
                + PEStringUtilities.formatDigit(empAccount
                        .getApplySalaryFixedAmmount()) + "</FIXEDAMOUNT>"
                + CR_LF;
        xmlString += "</SECOND>" + CR_LF;
        xmlString += "</SALARY>" + CR_LF;
        xmlString += "<BONUS>" + CR_LF;
        xmlString += "<FIRST>" + CR_LF;
        xmlString += "<BANKNAME>"
                + addEmpty(empAccount.getApplyBonusBank1() != null ? empAccount.getApplyBonusBank1().getBankName() : "")
                + "</BANKNAME>" + CR_LF;
        xmlString += "<BRANCHNAME>"
                + addEmpty(empAccount.getApplyBonusBank1() != null ? empAccount.getApplyBonusBank1().getBranchName() : "")
                + "</BRANCHNAME>" + CR_LF;
        xmlString += "<DEPOSITTYPE>"
                + addEmpty(empAccount.getApplyBonusDepositeTypeName1())
                + "</DEPOSITTYPE>" + CR_LF;
        xmlString += "<ACCOUNTNO>"
                + addEmpty(empAccount.getApplyBonusAccountNo1())
                + "</ACCOUNTNO>" + CR_LF;
        xmlString += "</FIRST>" + CR_LF;
        xmlString += "<SECOND>" + CR_LF;
        xmlString += "<BANKNAME>"
                + addEmpty(empAccount.getApplyBonusBank2() != null ? empAccount.getApplyBonusBank2().getBankName() : "")
                + "</BANKNAME>" + CR_LF;
        xmlString += "<BRANCHNAME>"
                + addEmpty(empAccount.getApplyBonusBank2() != null ? empAccount.getApplyBonusBank2().getBranchName() : "")
                + "</BRANCHNAME>" + CR_LF;
        xmlString += "<DEPOSITTYPE>"
                + addEmpty(empAccount.getApplyBonusDepositeTypeName2())
                + "</DEPOSITTYPE>" + CR_LF;
        xmlString += "<ACCOUNTNO>"
                + addEmpty(empAccount.getApplyBonusAccountNo2())
                + "</ACCOUNTNO>" + CR_LF;
        xmlString += "<FIXEDAMOUNT>"
                + PEStringUtilities.formatDigit(empAccount
                        .getApplyBonusFixedAmmount()) + "</FIXEDAMOUNT>"
                + CR_LF;
        xmlString += "</SECOND>" + CR_LF;
        xmlString += "</BONUS>" + CR_LF;
        xmlString += "</REQUEST>" + CR_LF;
        xmlString += "</U_EMPACCOUNT>" + CR_LF;
        return xmlString;
    }

    public EmpAccount findEmpAccount(Long empId) {

        EmpAccount empAccount = em.find(EmpAccount.class, empId);
        if (empAccount != null) {
            //口座種類の編集を行う
            empAccount.setCurrentSalaryDepositeTypeName1(getDepositeTypeName(empAccount.getCurrentSalaryDepositeType1()));
            empAccount.setCurrentSalaryDepositeTypeName2(getDepositeTypeName(empAccount.getCurrentSalaryDepositeType2()));
            empAccount.setCurrentBonusDepositeTypeName1(getDepositeTypeName(empAccount.getCurrentBonusDepositeType1()));
            empAccount.setCurrentBonusDepositeTypeName2(getDepositeTypeName(empAccount.getCurrentBonusDepositeType2()));

            empAccount.setApplySalaryDepositeTypeName1(getDepositeTypeName(empAccount.getApplySalaryDepositeType1()));
            empAccount.setApplySalaryDepositeTypeName2(getDepositeTypeName(empAccount.getApplySalaryDepositeType2()));
            empAccount.setApplyBonusDepositeTypeName1(getDepositeTypeName(empAccount.getApplyBonusDepositeType1()));
            empAccount.setApplyBonusDepositeTypeName2(getDepositeTypeName(empAccount.getApplyBonusDepositeType2()));
        }
        return empAccount;
    }

    private String getDepositeTypeName(String depositeType) {

        if (depositeType == null) {
            return null;
        }
        ClassInfo classInfo = classificationService.findClassInfo("0000000000", "1428", depositeType);
        if (classInfo == null) {
            return null;
        } else {
            return classInfo.getClassName();
        }
    }

    public void save(EmpAccount empAccount) {

        EmpAccount account = em.find(EmpAccount.class, empAccount.getEmpId());
        if (account == null) {
            // データベースに存在しないので新規
            em.persist(empAccount);
        } else {
            // すでに存在しているので更新
            em.merge(empAccount);
        }

    }

    public void commitEmpAccount(Long appRecepNo, String status) {

        String query = "SELECT empAccount FROM EmpAccount empAccount "
            + " WHERE empAccount.appRecepNo = :appRecepNo";
        EmpAccount empAccount = (EmpAccount)em.createQuery(query)
            .setParameter("appRecepNo", appRecepNo).getSingleResult();

        empAccount.setCurrentSalaryBank1(empAccount.getApplySalaryBank1());
        if (!nullOrBlank(empAccount.getApplySalaryAccountNo1())) {
            empAccount.setCurrentSalaryDepositeType1(empAccount.getApplySalaryDepositeType1());
            empAccount.setCurrentSalaryAccountNo1(empAccount.getApplySalaryAccountNo1());
        }
        empAccount.setCurrentSalaryBank2(empAccount.getApplySalaryBank2());
        if (!nullOrBlank(empAccount.getApplySalaryAccountNo2())) {
            empAccount.setCurrentSalaryDepositeType2(empAccount.getApplySalaryDepositeType2());
            empAccount.setCurrentSalaryAccountNo2(empAccount.getApplySalaryAccountNo2());
        }
        empAccount.setCurrentSalaryFixedAmmount(empAccount.getApplySalaryFixedAmmount());

        empAccount.setCurrentBonusBank1(empAccount.getApplyBonusBank1());
        if (!nullOrBlank(empAccount.getApplyBonusAccountNo1())) {
            empAccount.setCurrentBonusDepositeType1(empAccount.getApplyBonusDepositeType1());
            empAccount.setCurrentBonusAccountNo1(empAccount.getApplyBonusAccountNo1());
        }
        empAccount.setCurrentBonusBank2(empAccount.getApplyBonusBank2());
        if (!nullOrBlank(empAccount.getApplyBonusAccountNo2())) {
            empAccount.setCurrentBonusDepositeType2(empAccount.getApplyBonusDepositeType2());
            empAccount.setCurrentBonusAccountNo2(empAccount.getApplyBonusAccountNo2());
        }
        empAccount.setCurrentBonusFixedAmmount(empAccount.getApplyBonusFixedAmmount());

        em.flush();
    }

    private boolean nullOrBlank(String s) {
        if (s == null || "".equals(s)) {
            return true;
        } else {
            return false;
        }
    }
}
